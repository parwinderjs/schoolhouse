<?php 
 include_once("config.php");

 $first_name_error = $last_name_error = $email_error = $password_error = "";
 $first_name = $last_name = $email = "";
 
 if(isset($_POST['submit'])){

 	
 	if(empty($_POST['first_name'])){
 	 	$first_name_error = "(First name required)";
 	}else if (!preg_match("/^[a-zA-Z ]*$/",$_POST['first_name'])) {     // check name only contains letters and whitespace
		$first_name_error = "(Only letters and white space allowed)";
 	}else {
 		$first_name = htmlspecialchars($_POST['first_name']);
 	}

 	if(empty($_POST['last_name'])){
 		$last_name_error = "(Last name required)";
 	}else if (!preg_match("/^[a-zA-Z ]*$/",$_POST['last_name'])) {     // check name only contains letters and whitespace
		$last_name_error = "(Only letters and white space allowed)";
	}else {
 		$last_name = htmlspecialchars($_POST['last_name']);
 	}

 	if(empty($_POST['email'])){
 		$email_error = "(Email required)";
 	}else {
 		if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
 			$email_error = "(Email not valid)";
 		}else{
 			$email = $_POST['email'];
 		}
 	}

 	
 	if(empty($_POST['password'])){
 		$password_error = "(Password Required)";
 	}else {
 		if($_POST['password'] !== $_POST['password_check']){					// is password correct
 			$password_error = "(Password not matched)";
 		}else {
 			$password = htmlspecialchars($_POST['password']);
 		}
 	}

 	$conn = connect();

 	// if email is already there
 	try {
 		checkEmail($conn, $email);
 	}
 	catch(Exception $e)
 	{
 		$email_error = $e->getMessage();
 		return;
 	}

 	// insert into database if no error 
 	if(empty($first_name_error) && empty($last_name_error) && empty($email_error) && empty($password_error)){
 		if(insert($conn, $first_name,$last_name,$email,$password)){
 		header('Location:stdRegisteredAlert.html');
 		}else{
 		header('Location:stdErrorRegistering.html');
 		}		
 	}else {
 		//nothing;
 	}
 }



function checkEmail($con, $email){
 	$query = "SELECT `email` FROM `students` WHERE `email` = '$email'";
 	$result = mysqli_query($con, $query);
 	if(mysqli_num_rows($result) > 0){
 			throw new Exception("Email already exists", 1);
 		}
 }


function insert($con, $first_name,$last_name,$email,$password){
 	$f_name = mysqli_escape_string($con,$first_name);
 	$l_name = mysqli_escape_string($con,$last_name);
 	$email_s = mysqli_escape_string($con,$email);
 	$password = mysqli_escape_string($con,$password);
 	$insert = "INSERT INTO `students` (`first_name`,`last_name`,`email`,`password`) VALUES ('$first_name','$last_name','$email','$password')";
 	@mysqli_query($con,$insert);
 	if(mysqli_affected_rows($con) == 1){
 		return true;
 	}else {
 		return false;
 	}
 }

?>