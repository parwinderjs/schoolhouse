<?php
session_start();
if(!isset($_SESSION['std_username'])){
        header("location:NotLogedIn.html");
}else{
$username = $_SESSION['std_username'];
$student_id = $_SESSION['std_id'];
$_SESSION['previous_visited'] = basename($_SERVER['PHP_SELF']);
}
?>

<?php
    include_once("config.php");
    $conn = connect();
    function checkCourseUpdate($conn, $student_id){
        //$select = "SELECT COUNT(student_id) FROM `joined` WHERE `newtopic` IS NOT NULL";
        $result = mysqli_query($conn, $select);
        if($result){
            $row = mysqli_fetch_array($result);
            $count = $row['0'];
            return $count;
        }else{
            return false;
        }
    }

    $update = false;//checkCourseUpdate($conn, $student_id);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Panel</title>
	<link rel="stylesheet" type="text/css" href="css/cerulean.min.css">
	<!--link rel="stylesheet" type="text/css" href="css/simple-sidebar.css"-->

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="std_view/CourseDetail.php">Search Courses</a></li>
            <li><a href="std_view/CourseJoined.php">Joined courses<?php if($update){ echo "&nbsp<span class='badge'>$update</span>";} ?></a></li>
            <li><a href="std_view/bookmarks.php">Bookmarks</a></li>
            <li><a href="std_view/QuestionsView.php">Questions</a></li>
            <li><a href="student_level-1/stdInteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $username; ?></a></li>
                <li><a href="Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<div class="jumbotron" style="text-align: center"><h1>WELCOME STUDENT</h1></div>
</div>
</body>
</html>