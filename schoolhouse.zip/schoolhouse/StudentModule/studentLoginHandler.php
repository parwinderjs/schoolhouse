<?php 

include "Config.php";
$email_error = $password_error = "";

if(isset($_POST['submit'])){
	if(empty($_POST['email'])){
		$email_error = "(field is empty)";
	}

	if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
		$email_error = "(email not valid)";
	}

	if(empty($_POST['password'])){
		$password_error = "(Password field empty)";
	}

	if(empty($email_error) && empty($password_error)){
		$con = connect();
		$email = mysqli_escape_string($con, $_POST['email']);
		$password = mysqli_escape_string($con, $_POST['password']);
		$select = "SELECT * FROM `students` WHERE `email` = '$email' AND `password` = '$password'";

		$result = mysqli_query($con, $select);
		if(mysqli_num_rows($result) == 1){
			$row = mysqli_fetch_assoc($result);
			$_SESSION['std_username'] = $row['first_name'];
			$_SESSION['std_id'] = $row['id'];
			header("location:studentPanel.php");
		}
	}	
}//endmainif
 ?>