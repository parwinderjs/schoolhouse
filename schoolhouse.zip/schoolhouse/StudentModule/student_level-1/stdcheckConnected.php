<?php 
if(isset($_POST['check'])){
	$std_username = $_POST['std_username'];
    $conn = mysqli_connect("localhost","root","Akalsahae","schoolhouse");

    $select = "SELECT * FROM `connected` WHERE `name` != '$std_username'";   //exclude the one who is checking   // + add WHERE student is joined with specific teacher
    $result = mysqli_query($conn, $select);
    $connected = array();
    while($row = mysqli_fetch_assoc($result)){
        $connected[] = $row['name'];    }
        echo json_encode($connected);
}    
?>