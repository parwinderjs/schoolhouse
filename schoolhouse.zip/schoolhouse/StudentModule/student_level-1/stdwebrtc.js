$(document).ready(function(){
var localAudio;                 // holds local audio element
var remoteAudio;                // holds remote audio element
var serverConnection;
var peerConnection;             // holds object of RTCPeerConnection
var dc;                         // holds datachannel object
var peerConnectionConfig = {'iceServers': [{'url': 'stun:stun.services.mozilla.com'}, {'url': 'stun:stun.l.google.com:19302'}]};
// stun (Session Traversal Utilities for NAT) 
var connection = {
    'optional': [
       //{'DtlsSrtpKeyAgreement': true},
       //{'RtpDataChannels': true}
        ]
};

var isCaller;

// cross browser support below
navigator.getUserMedia = navigator.getUserMedia || navigator.mozGetUserMedia || navigator.webkitGetUserMedia;
window.RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
window.RTCIceCandidate = window.RTCIceCandidate || window.mozRTCIceCandidate || window.webkitRTCIceCandidate;
window.RTCSessionDescription = window.RTCSessionDescription || window.mozRTCSessionDescription || window.webkitRTCSessionDescription;

pageReady();

/*Initializes things needed before connecting*/
function pageReady() {
    localAudio = document.getElementById('localAudio');
    remoteAudio = document.getElementById('remoteAudio');
    console.log("Username : " + g_std_username);
    
//-------------------------------------------------websocket server work---------------------------------------------------
    serverConnection = new WebSocket('ws://localhost:8080/ws/');                       //('ws://192.168.1.4/ws/');               // creating websocket server object
    serverConnection.onopen = function(){                                   // on open send who is connected to ws server
        console.log("WebSocket : Connected");
        var identity = {
                        "subject": "identity",
                        "name":g_std_username,
                        "type": "student"
                        };
        serverConnection.send(JSON.stringify(identity));
    }
    serverConnection.onmessage = gotMessageFromServer;

//------------------------------------------------access user media--------------------------------------------------------
    var constraints = {                                                     // constraints for accessing user media
        //video: true,
        audio: true, 
    };

    if(navigator.getUserMedia) {
        navigator.getUserMedia(constraints, getUserMediaSuccess, getUserMediaError);
    } else {
        alert('Your browser does not support getUserMedia API');
    }
    
    /*Adds stream generated to local audio element*/
    function getUserMediaSuccess(stream) {
        g_local_stream = stream;                                            // used in stdInteractiveMode.php for check                              
        localStream = stream;
        localAudio.src = window.URL.createObjectURL(stream);
    }

    /*Displays error if any for user media access*/
    function getUserMediaError(error) {
        console.log(error);
    }
}


/* creates peer connection object */
function start(isCaller) {
    peerConnection = new RTCPeerConnection(peerConnectionConfig, connection);
    peerConnection.onicecandidate = gotIceCandidate;
    peerConnection.onaddstream = gotRemoteStream;
    peerConnection.addStream(localStream);

    datachannel(peerConnection, isCaller);
    console.log(peerConnection.iceConnectionState);
    manageSession();

    if(isCaller) {
        peerConnection.createOffer(gotDescription, createOfferError);
    }
}

/* ws server message handler */
function gotMessageFromServer(message) {

    var signal = JSON.parse(message.data);
    //if(signal.name){console.log(signal.name); return}
    var sender = signal.from;
    var accepted = false;
    
    if(signal.subject == "disconnection"){
        var disconnected_peer = signal.peer;
        peerConnection.close();
        alert(disconnected_peer + " has disconnected. Session closed!");
        location.reload();
    }

    if(signal.subject == "sdp" && signal.sdp.type === "offer"){
        accepted = window.confirm("Accept Offer from " + sender);
        if(accepted){
            if(g_local_stream == null){
                while(g_local_stream == null){
                alert("Please share your microphone and then click Ok");
                }//endloop
            } 
            if(g_local_stream){
                    if(!peerConnection) start(false);
                    g_check_flag = false;
                    $("#preView").hide();
                    $("#interface").show();
                    g_receiver = signal.from;
            }
        }else{
            alert("Offer rejected or an error occured");
            location.reload();
            return;
        }   
    }
if(peerConnection){
    if(signal.subject == "sdp") {
        if(signal.sdp.type === "offer"){            // if  it is an offer
            peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp), function(){peerConnection.createAnswer(gotDescription, createAnswerError);}, function(err){console.log(err)});
        } 
        if(signal.sdp.type === "answer"){                                     // if it is an answer
            peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp),function(){},function(error){console.log(error)});
        }
    } else if(signal.subject == "ice") {
        peerConnection.addIceCandidate(new RTCIceCandidate(signal.ice));
    }  
}    
}//endfn

/* on generation of ice candidates */
function gotIceCandidate(event) {
    if(event.candidate != null) {
        var candidate = {
                    "subject": "ice",
                    "to": g_receiver,
                    "from":g_std_username,
                    'ice': event.candidate
        }
        serverConnection.send(JSON.stringify(candidate));
    }
}

/* on generation of sdp candidates */
function gotDescription(description) {
    console.log('got description');
    peerConnection.setLocalDescription(description, function () {
         var sdp = {
                "subject": "sdp",
                "to": g_receiver,
                "from": g_std_username,
                "sdp" : description
         }
        serverConnection.send(JSON.stringify(sdp));
    }, function() {console.log('set description error')});
}

function gotRemoteStream(event) {
    console.log("got remote stream");
    remoteAudio.src = window.URL.createObjectURL(event.stream);
}

// Error functions....


function createOfferError(error) {
    console.log(error);
}

function createAnswerError(error) {
    console.log(error);
}

/* Data channel work */
function datachannel(peerConnection, isCaller){
    dc = peerConnection.createDataChannel("chat", {reliable: true});            // create datachannel object
    console.log("Channel id: " + dc.id);    
    console.log("Channel state: " + dc.readyState);

    dc.onopen = function () {
        //console.log("datachannel open");
        console.log("Channel state: " + dc.readyState);
        if(isCaller){
        dc.onerror = function(ev) { console.log("onerror event detected!"); };
        }
    
//--------------------------------------------------Chat service---------------------------------------------------------    
    $("#send").click(function(){
        var value = $("#input").val();
        $('#chat').append("<p><strong>You : </strong>" + value + "</p>");
        var message = {
            "subject": "chat",
            "from": g_std_username,
            "text": value
        }
        dc.send(JSON.stringify(message));
    }); 

//-------------------------------------------------Whiteboard sync-------------------------------------------------------

    var sendImg = function(e){
        var dataURL = canvas.toDataURL();
        var message = {                                     // -----------------------------------------------------
            "subject": "canvas",
            "from": g_std_username,
            "data": dataURL
        }
        dc.send(JSON.stringify(message));
        findxy('up', e);
    }
    $('#can').mouseup(sendImg);

    // if you clear whole canvas
    $("#erase").click(function(){
        dc.send(JSON.stringify({"subject": "canvas_delete", "message": "erase_all"}));
    });   
    
    /* on creation of data channel*/    
    peerConnection.ondatachannel = function (event) {               // receiving via datachannel
        //console.log(event.channel);                                
        receiveChannel = event.channel;                             // event.channel is channel object
        receiveChannel.onmessage = function(event){
        console.log("received data");
        message = JSON.parse(event.data);

        //handle message for chat service
        if(message.subject === "chat"){
            $('#chat').append("<p><strong>" + message.from + " : </strong>" + message.text + "</p>");
        }
        //handle message for whiteboard(canvas) sync
        if(message.subject === "canvas"){
            var img = new Image;                                //create image object
            ctx = $('#can').get(0).getContext('2d');            // get canvas element
            img.onload = function(){                            // on loading of img
              ctx.drawImage(img,0,0);                           // draw it on canvas
                };
            img.src = message.data;                             // add data received to image source            
        }
        
        if(message.subject === "canvas_delete"){
            //window.alert("Canvas Cleared");
            clearArea();
        }
        };
    };
    };//endfn
}//endfn

function manageSession(){
peerConnection.oniceconnectionstatechange = function() {
    console.log(peerConnection.iceConnectionState);
    if(peerConnection.iceConnectionState == 'connected'){
        var session = {
                "subject": "session",
                "peer1": g_std_username,
                "peer2":g_receiver
        }
        serverConnection.send(JSON.stringify(session));
        alert("Connected with " + g_receiver);
    }

    if(peerConnection.iceConnectionState == 'disconnected') {
        alert(g_receiver + ' Disconnected');
    }
}
}

$("#call").click(function(){
    start(true);   
});

});//endreadyfunction