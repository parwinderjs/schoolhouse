<script type="text/javascript">
    $(function(){
        $("#chat-button").click(function(){
            $(this).hide();
            $("#chat-box").css("display","block");
        });

        $("#chat-box-close").click(function(){
            $("#chat-box").hide();
            $("#chat-button").show();
        });
    });

</script>

<!-- chat button and chat box -->

        <div id="chat-button" class="chat-button"><div class="btn btn-primary">Chat</div></div>

        <div id="chat-box" class='panel panel-primary col-md-3' style="position: fixed; bottom: 0; right: 0; z-index: 9998; display: none;">
            <div id="chat-box-close" class='panel-heading'><h1 class='panel-title' style="cursor: pointer">Chat box</h1></div>
            <div class='panel-body' style="overflow: scroll; min-height: 50%">
                <ul class="chat" id="chat">
                    <!-- chat messages displayed here -->        
                </ul>
            </div>
                <div class="panel-footer">
                    <div class="input-group">
                        <input id="input" class="form-control input-sm" placeholder="Type your message here..." type="text">
                        <span class="input-group-btn">
                            <button class="btn btn-warning btn-sm" id="send">Send</button>
                        </span>
                    </div>
                </div>
        </div>
<!-- blockend -->  