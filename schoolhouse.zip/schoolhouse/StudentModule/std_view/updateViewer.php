<?php  
	session_start();
    if(isset($_SESSION['std_id'])){
    $std_id = $_SESSION['std_id'];
	}else{
		header("Location:../NotLogedIn.html");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>CourseContent</title>
	<link rel="stylesheet" href="css/cerulean.min.css">
	<script src="js/jquery-1.9.1.js"></script>
</head>
<body>
<div class="container">
<div class="page-header">

<?php 
include_once("config.php");
$conn = connect();
if(isset($_POST['course_id'])){
 $course_id = $_POST['course_id'];
 $course_name = $_POST['course_name'];
 echo "<h1>$course_name</h1><span class='label label-info'>updates</span></div>";

 $select = "SELECT * FROM `topics` WHERE `course_id` = '$course_id' AND `timeadded` > (NOW() - INTERVAL 5 DAY)";
 $result = mysqli_query($conn, $select);
 if($result){
 	if(mysqli_num_rows($result)>0){
 		echo "<ul class='list-group'><li class='list-group-item list-group-item-info'><h4 class='list-group-item-heading'>New Topics</h4></li>";
 		while($row = mysqli_fetch_assoc($result)){
 			$topic_id = $row['id'];
 			$topic_name = $row['topic_name'];
 			echo "<li class='list-group-item'><a href='VideoPlayer.php?video=$topic_id'>".$topic_name."</a></li>";
 		}
 		echo "</ul>";
 	}
 }
}
?>
<script>
var g_course_id = <?php echo $course_id; ?>;
var g_std_id = <?php echo $std_id; ?>;
</script>
</div>
</body>
</html>
<?php 
function topicName($conn, $topic_id){
	if($conn){
		$select = "SELECT * FROM `topics` WHERE `id` = '$topic_id'";
		$result = mysqli_query($conn, $select);
		$row = mysqli_fetch_assoc($result);
		if($result){
		return $row['topic_name'];
		}else{
		return "unkown";
		}
	}
}
 ?>
