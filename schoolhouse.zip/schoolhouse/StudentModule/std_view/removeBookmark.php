<?php 

include_once("config.php"); 
if(isset($_POST['std_id']) &&  isset($_POST['topic_id'])){
	$student_id = $_POST['std_id'];
	$topic_id = $_POST['topic_id'];
	$conn = connect();
	$delete = "DELETE FROM `bookmarked` WHERE `student_id` = '$student_id' AND `topic_id` = '$topic_id'";
	mysqli_query($conn, $delete);
	if(mysqli_affected_rows($conn)>0){
		echo json_encode("removed");
	}
}
?>

