<?php
include_once("config.php");

session_start();
if(isset($_SESSION['std_id']) && isset($_SESSION['std_username'])){
    $std_username = $_SESSION['std_username'];
    $std_id = $_SESSION['std_id'];
}else{
	header("Location:../NotLogedIn.html");
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Questions</title>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/cerulean.min.css">
</head>
<?php 
	$conn = connect();
	if($conn){
		$select = "SELECT * FROM `questions` WHERE `student_id` = '$std_id'";
		$result = mysqli_query($conn, $select);
	}

function topicAuthor($conn, $topic_id){
	if($conn){
		$select = "SELECT * FROM `teachers` WHERE `id` = (SELECT `teacher_id` FROM `courses` WHERE `id` = (SELECT `course_id` FROM `chapters` WHERE `id` = (SELECT `chapter_id` FROM `topics` WHERE `id` = '$topic_id')))";
		$result2 = mysqli_query($conn, $select) or die(mysqli_error($conn));
		if($result2){
			if(mysqli_num_rows($result2)>0){
				$row = mysqli_fetch_assoc($result2);
				return $row['first_name']." ".$row['last_name']; 	
			}else{
				return "N/A";
			}
		}else{
			echo "Not available";
		}
	}
}	

function topicName($conn, $topic_id){
	if($conn){
		$select = "SELECT * FROM `topics` WHERE `id` = '$topic_id'";
		$result = mysqli_query($conn, $select);
		$row = mysqli_fetch_assoc($result);
		if($result){
			if(mysqli_num_rows($result)>0){
				return $row['topic_name'];		
			}else{
				return "N/A";
			}
		
		}else{
			echo "Not available";
		}
	}
}

function getAnswer($conn, $question_id){
	$select = "SELECT * FROM `answers` WHERE `question_id` = '$question_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		$row = mysqli_fetch_assoc($result);
		return $row['answer'];
	}
}
?>
<body>
<div class="container">
	<!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../studentPanel.php">Home</a></li>
            <li><a href="./CourseDetail.php">Search Courses</a></li>
            <li><a href="./CourseJoined.php">Joined courses<?php //if($update){ echo "&nbsp<span class='badge'>$update</span>";} ?></a></li>
            <li><a href="./bookmarks.php">Bookmarks</a></li>
            <li class="active"><a href="./QuestionsView.php">Questions</a></li>
            <li><a href="../student_level-1/stdInteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $std_username; ?></a></li>
                <li><a href="../Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<!--nav end -->    
<br>

    <div class="jumbotron" style="text-align: center;">
        <h1>QUESTION PANEL</h1>
    </div>

	<div class="container">
		<h2>Your Questions</h2>
		<div class="panel-group">
		<?php
			if($result){
			$i = 1;
			while($row = mysqli_fetch_assoc($result)){
			$author = topicAuthor($conn, $row['topic_id']);
			echo "<div class='panel panel-primary'>";
			echo "<div class='panel-heading'><h4 class='panel-title'>Q:$i : ".$row['question']."</h4></div>";
			echo "<div class='panel-body'>";
			if($row['status'] == 'answered'){
				echo "<blockquote><span class='label label-success'>Ans</span><br><pre>".getAnswer($conn, $row['id'])."</pre><footer>by $author</footer></blockquote>";
			}
			echo "<span class='col-md-3'><span class='label label-info'>Status</span> : ".$row['status']." </span><span class='col-md-3'><span class='label label-info'>On topic</span> : ".topicName($conn, $row['topic_id'])."</span><span class='col-md-3'><span class='label label-info'>Topic Author</span> : ".$author."</span></div>";
			echo "</div>";
			$i++;
			}//endwhile
			}else{
				if(mysqli_num_rows($result) == 0){
					echo "There's no questions yet";
				}
			}
		?>	
		</div>
	</div>
</div>
</body>
</html>