<?php
include_once("config.php"); 
    session_start();
    if(isset($_SESSION['std_id'])){
    $std_id = $_SESSION['std_id'];
    $std_username = $_SESSION['std_username'];
	}else{
		header("Location:../NotLogedIn.html");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Bookmarks</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>


<link rel="stylesheet" href="./src/jquery.contextMenu.css">
<script src="./src/jquery.contextMenu.js"></script>
<script src="./src/jquery.ui.position.min.js"></script>
<script>
var g_std_id = <?php echo $std_id; ?>;
$(function() {
        $.contextMenu({
            selector: '.list-group-item',                                                      // element class or id to be selected
            callback: function(key, options) {
                var m = "clicked: " + key + " on " + $(this).text();
                var prev = $(this).text();
                console.log(prev);
                topic_id = $(this).attr("id");							// -| topic id is stored as 'id' of element
                //window.console && console.log(m) || alert(m);
                if(key == "remove"){
                	$.ajax({
						url: "removeBookmark.php",
						method: "post",
						data: {
							"std_id" : g_std_id,
							"topic_id" : topic_id
						},
						success: function(result, status){
							if(JSON.parse(result) === "removed"){
							location.reload();
							}
						}
					});	
                }
            },
            items: {
                "remove": {name: "Remove", icon: "delete"}
            }
        });
});
</script>
</head>
<body>
<div class='container'>
	<!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../studentPanel.php">Home</a></li>
            <li><a href="./CourseDetail.php">Search Courses</a></li>
            <li><a href="./CourseJoined.php">Joined courses<?php //if($update){ echo "&nbsp<span class='badge'>$update</span>";} ?></a></li>
            <li class="active"><a href="./bookmarks.php">Bookmarks</a></li>
            <li><a href="./QuestionsView.php">Questions</a></li>
            <li><a href="../student_level-1/stdInteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $std_username; ?></a></li>
                <li><a href="../Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<!--nav end -->    
<br>

    <div class="jumbotron" style="text-align: center;">
        <h1>BOOKMARKS</h1>
    </div>
<?php
$conn = connect();

getBookmarks($conn, $std_id);

function getBookmarks($conn, $student_id){
	$select = "SELECT * FROM `bookmark_folders` WHERE `student_id` = '$student_id'";
	$result = mysqli_query($conn, $select);
		if($result){
			echo "<ul class='list-group'>";
			while($row = mysqli_fetch_assoc($result)){
				$folder_name = $row['folder_name'];
				$folder_id = $row['id'];
				echo "<li class='list-group-item list-group-item-primary'><h4 class='list-group-item-heading'>".$folder_name."</h4></li>";
				displayTopic($conn, $folder_id);
			}
		}
}

function displayTopic($conn, $folder_id){
	$select = "SELECT * FROM `bookmarked` WHERE `folder_id` = '$folder_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		if(mysqli_num_rows($result)>0){
			while($row = mysqli_fetch_assoc($result)){
			$topic_id = $row['topic_id'];
			$topic_name = getTopicName($conn, $topic_id);
			echo "<li class='list-group-item' id=$topic_id><a href='VideoPlayer.php?video=$topic_id'>".$topic_name."</a></li>";
			}
		}else{
			//echo "<i>NILL</i>";
		}
	}
		
}

function getTopicName($conn, $topic_id){
	if($conn){
		$select = "SELECT * FROM `topics` WHERE `id` = '$topic_id'";
		$result = mysqli_query($conn, $select);
		$row = mysqli_fetch_assoc($result);
		if($result){
			if(mysqli_num_rows($result) == 0){
				return NULL;		
			}else{
				return $row['topic_name'];
			}
		}else{
		}
	}
}



function isDeleted($conn, $topic_id){
	$select = "SELECT * FROM `notification` WHERE `action` = 'DELETED' AND `id` = '$topic_id' AND `type` = 'topic'";
	$result = mysqli_query($conn, $select);
	if($result){
		if(mysqli_num_rows($result)>0){
			$row = mysqli_fetch_assoc($result);
			return $row['name']." (deleted by its author)<input type='button' id=$topic_id class='btn btn-xs btn-primary remove-bookmark' style='float: right' value='remove bookmark'></input>";
		}
	}
} 

?>
</div>	
<script>
	$(function(){
		$(".remove-bookmark").click(function(){
			var topic_id = $(".remove-bookmark").attr('id');				// trick : stored topic id as element id
			console.log(topic_id);

			$.ajax({
				url: "removeBookmark.php",
				method: "post",
				data: {
					"std_id" : g_std_id,
					"topic_id" : topic_id
				},
				success: function(result, status){
					if(JSON.parse(result) === "removed"){
					location.reload();
					}
				}
			});
		});
	});
</script>
</body>
</html>
