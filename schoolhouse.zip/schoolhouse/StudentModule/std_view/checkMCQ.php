<?php 
 session_start();
    if(isset($_SESSION['std_username'])){
    $std_username = $_SESSION['std_username'];
    $std_id = $_SESSION['std_id'];
    }else{
    	header('Location: ./NotLogedIn.html');
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Solve MCQ</title>

	<link rel="stylesheet" href="../jquery-ui/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script src="../jquery-ui/jquery-ui.min.js"></script>
</head>
<body>
<div class="container">
<div class="page-header">
<h1>MCQ Result</h1>
</div>
<?php
include_once("config.php");
$conn = connect();  
if(isset($_POST['submit']) && isset($_POST['topic_id'])){

	$topic_id = $_POST['topic_id'];

	$select = "SELECT * FROM `mcq` WHERE `topic_id` = '$topic_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		if(mysqli_num_rows($result)>0){
			$count = mysqli_num_rows($result);
			$i = 1;
			$correct = 0;
			$incorrect = 0;
			echo "<div class='panel-group panel-primary'>";
			while($row = mysqli_fetch_assoc($result)){
				$question_id = $row['id'];
				$question = $row['question'];
				$option1 = $row['option1'];
				$option2 = $row['option2'];
				$option3 = $row['option3'];
				$option4 = $row['option4'];
				if(isset($_POST[$question_id])){
				$user_option = $_POST[$question_id];
				}else{
					$user_option = NULL;
				}
				$correct_option = $row['correct_option'];	
				if($user_option == $correct_option){
					display($i, $question, $option1, $option2, $option3, $option4, $correct_option, "");
					$correct++;
				}else{
					if(is_null($user_option)){
						display($i, $question, $option1, $option2, $option3, $option4, $correct_option, "0");
					}else{
						display($i, $question, $option1, $option2, $option3, $option4, $correct_option, $user_option);
						$incorrect++;
					}
				}
				$i++;
			}
			echo "</div>";
			echo "<div class='panel-footer'>";
			echo "<span style='color: blue'>Total Questions = $count</span><br>";
			echo "<span style='color: green'>Correct response = $correct</span><br>";
			echo "<span style='color: red'>Incorrect response = $incorrect</span><br>";
			echo "<h2 style='text-align: center;'>Accuracy = ";
			$acc = ($correct/$count)*100;
			$f = sprintf ("%.2f",$acc);
			echo $f."%</h2></div>";
		}
	}	
}

function display($question_no, $question, $option1, $option2, $option3, $option4, $correct_option, $wrong_option){
				echo "<div class='panel-heading'>Question $question_no : ".$question;
				if(!empty($wrong_option)){
					echo "<span class='label label-danger' style='float: right'>Incorrect response</span><br>";
				}else if($wrong_option == "0"){
					echo "<span class='label label-info' style='float: right'>Not answered</span><br>";
				}else{
					echo "<span class='label label-success' style='float: right'>Correct response</span><br>";
				}
				echo "</div>";

				echo "<div class='panel-body' style='clear: both'>";
				if($wrong_option == 1){
					echo "<span style='background-color: red'>".$option1."</span><br>";
				}else{
					if($correct_option == 1){
					echo "<span style='background-color: green'>".$option1."</span><br>";	
					}else{
					echo "<span>".$option1."</span><br>";	
					}	
				}
				if($wrong_option == 2){
					echo "<span style='background-color: red'>".$option2."</span><br>";
				}else{
					if($correct_option == 2){
					echo "<span style='background-color: green'>".$option2."</span><br>";	
					}else{
					echo "<span>".$option2."</span><br>";	
					}
				}
				if($wrong_option == 3){
					echo "<span style='background-color: red'>".$option3."</span><br>";
				}else{
					if($correct_option == 3){
					echo "<span style='background-color: green'>".$option3."</span><br>";	
					}else{
					echo "<span>".$option3."</span><br>";	
					}		
				}
				if($wrong_option == 4){
					echo "<span style='background-color: red'>".$option4."</span><br>";
				}else{
					if($correct_option == 4){
					echo "<span style='background-color: green'>".$option3."</span><br>";	
					}else{
					echo "<span>".$option4."</span><br>";	
					}		
				}
				echo "</div>";
	}
?>
</div>
</body>
</html>
