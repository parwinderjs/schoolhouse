<?php 
session_start();
if(!isset($_SESSION['std_username'])){
        header("location:NotLogedIn.html");
}else{
$std_username = $_SESSION['std_username'];
$student_id = $_SESSION['std_id'];
}
/*
if (isset($_SESSION['previous_visited'])) {
   if (basename($_SERVER['PHP_SELF']) != $_SESSION['previous_visited']) {       //if previous page is not the same as current page
        unset($_SESSION['keyword']);                                    // unset the session keyword
   }
}
//$_SESSION['previous_visited'] = basename($_SERVER['PHP_SELF']);                 
*/
/*
if(isset($_POST['submit'])){
  if(!empty($_POST['keyword'])){
  $_SESSION['keyword'] = $_POST['keyword'];
  }else{
    unset($_SESSION['keyword']);
  }
}
if(isset($_SESSION['keyword'])){
  $keyword = $_SESSION['keyword'];
}
*/
if(isset($_POST['submit'])){
  if(!empty($_POST['keyword'])){
    $keyword = $_POST['keyword'];
  }
}
if(isset($_GET['keyword'])){
  $keyword = $_GET['keyword'];
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>CourseDetail</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../studentPanel.php">Home</a></li>
            <li class="active"><a href="./CourseDetail.php">Search Courses</a></li>
            <li><a href="./CourseJoined.php">Joined courses<?php //if($update){ echo "&nbsp<span class='badge'>$update</span>";} ?></a></li>
            <li><a href="./bookmarks.php">Bookmarks</a></li>
            <li><a href="./QuestionsView.php">Questions</a></li>
            <li><a href="../student_level-1/stdInteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $std_username; ?></a></li>
                <li><a href="../Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<!--nav end -->    
<br>

    <div class="jumbotron" style="text-align: center;">
        <h1>SEARCH COURSES</h1>
    </div>

  <div class="container">
            <form method="post" id="search_form" class="form-search form-horizontal pull-left">
                <div class="input-append span12">
                    <input type="text" name="keyword" class="search-query" placeholder="Search">
                    <button type="submit" name="submit" class="btn btn-info btn-sm">Search</button>
                </div>
            </form>
    
  </div>
<br />

<?php  
include_once("../Classes/SearchCourse.php");
include_once("config.php");
$conn = connect();

//create query
if(isset($keyword) && !empty($keyword)){
    $keyword_safe = mysqli_escape_string($conn, $keyword);
    $select = "SELECT * FROM `courses` WHERE `course_name` LIKE '%$keyword_safe%'";
}else{
    $select = "SELECT * FROM `courses`";  
}

//if(!isset($keyword)){ $keyword = null };
$search = new Search($select, 1, @$keyword);              // @ for ignoring undefined error
$rs = $search->getPageResult();

if(!$rs){echo "No courses result for $keyword";}
if($rs){
  if(mysqli_num_rows($rs) == 0){ echo "No courses result for $keyword"; exit;}

echo "<div class='panel-group' id='accordion'>";
while($row = mysqli_fetch_assoc($rs)){
	 echo "<div class='panel panel-default'>";
     echo "<div class='panel-heading'>"; 	
     echo "<h4 class='panel-title'>";
     echo "<a data-toggle='collapse' data-parent='#accordion' href='#collapse".$row['id']."'>".$row['course_name']."</a>";
     echo "<span style='float:right'>(by ".getTeacherName($row['teacher_id'], $conn).")</span>";
     echo "</h4>";
     
     echo "</div>";
     echo "<div id='collapse".$row['id']."' class='panel-collapse collapse in'><div class='panel-body'>";
     echo $row['detail'];
     echo "<br /><br/>";
     selectChapters($row['id'], $conn);
     
     
     echo "</div></div></div>";
	}

  echo "<br /><center><ul class='pagination pagination-sm'>";
  echo  $search->renderFullNav();
  echo "</ul></center>";
}//endif
 function selectChapters($course_id, $conn){
    $query = "SELECT * FROM `chapters` WHERE chapters.course_id = '$course_id'";
    $result = mysqli_query($conn, $query)  or mysqli_error($conn);
    if($result){
      if(mysqli_num_rows($result) == 0){
        echo "&nbsp&nbsp<i>Null</i>";
      }else{
        echo "&nbsp<form method='post' action='TopicShow.php' class='form-inline'><label class='control-label'>Select Chapter &nbsp</label><select name='chapter_id'>";
        while($chapter = mysqli_fetch_assoc($result)){
        echo "<option value='".$chapter['id']."'>";
        echo $chapter['chapter_name'];
        echo "</option>";
        }
        echo "</select>&nbsp<button type='submit' name='submit' class='btn btn-default btn-xs'>GO</button></form>";
      }
    }  
 }

 function getTeacherName($teacher_id, $conn){
    $query = "SELECT * FROM `teachers` WHERE `id` = '$teacher_id'";
    $result = mysqli_query($conn, $query);
    if($result){
      if(mysqli_num_rows($result)>0){
        $row = mysqli_fetch_assoc($result);
        return $row['first_name']." ".$row['last_name'];
      }
    }
 } 

?>
</div>
</body>
</html>
