$(function() {
    function ratingEnable() {
        $('#rating-pill').barrating('show', {
            theme: 'bars-pill',
            initialRating: g_initial_rating,//'-1',
            showValues: true,
            showSelectedRating: false,
            onSelect:function(value, text) {
                //alert(g_std_id + 'Selected rating: ' + value + 'on topic' + g_topic_id);
                $.ajax({
                    url:"saveRating.php",
                    method:"post",
                    data:{
                        "student_id": g_std_id,
                        "topic_id": g_topic_id,
                        "rating": value
                    },
                    success: function(result, status){
                            console.log(result);
                    }
                });
            }
        });
    }

    ratingEnable();
});
