<?php 
include_once("config.php"); 

if(isset($_POST['folder_name']) && isset($_POST['std_id']) && isset($_POST['topic_id'])){
	$conn = connect();
	$folder_name = $_POST['folder_name'];
	$student_id = $_POST['std_id'];
	$topic_id = $_POST['topic_id'];

	$select = "SELECT * FROM `bookmark_folders` WHERE `folder_name` = '$folder_name'";

	$result = mysqli_query($conn, $select);
	$row = mysqli_fetch_assoc($result);
	$folder_id = $row['id'];

	$insert = "INSERT INTO `bookmarked` (`student_id`, `topic_id`, `folder_id`) VALUES ('$student_id','$topic_id', '$folder_id')";
	mysqli_query($conn, $insert);
	if(mysqli_affected_rows($conn) > 0){
		echo "added";
	}
}
?>