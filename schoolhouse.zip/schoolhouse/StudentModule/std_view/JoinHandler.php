<?php 

	include_once("config.php");
	if(isset($_POST['student_id'])){
		$student_id = $_POST['student_id'];
		$course_id = $_POST['course_id'];

		$conn = connect();

		if($_POST['action'] == "add"){
			if(isDuplicate($conn, $student_id, $course_id)){
				return false;
				exit;
			}
			$insert = "INSERT INTO `joined`(`student_id`, `course_id`) VALUES ('$student_id', '$course_id')";
			if(mysqli_query($conn, $insert)){
				echo true;
			}else { 
				echo mysqli_error($conn); 
			}			
		}else if($_POST['action'] == "delete"){
			$delete = "DELETE FROM `joined` WHERE `student_id` = '$student_id' AND `course_id` = '$course_id'";
			if(mysqli_query($conn, $delete)){
				echo true;
			}else { 
				echo false; 
			}
		}
	}

	// this function is not required now
	function isDuplicate($conn, $student_id, $course_id){
		$select = "SELECT * FROM `joined` WHERE `student_id` = '$student_id' AND `course_id` = '$course_id'";
		if($result = mysqli_query($conn, $select)){
			if(mysqli_num_rows($result) > 0){
				return true;
			}else{
				return false;
			}
		}
	}
 ?>