<?php
include_once("config.php"); 
if(isset($_POST['folder_name'])){
	$conn = connect();
	$student_id = intval($_POST['std_id']);
	$folder_name = mysqli_escape_string($conn, $_POST['folder_name']);
	$insert = "INSERT INTO `bookmark_folders` (`folder_name`, `student_id`) VALUES ('$folder_name', '$student_id')";
	$result = mysqli_query($conn, $insert);
	if(mysqli_affected_rows($conn) > 0){
		echo $folder_name;							// send back folder_name
	}else{
		echo "false";								
	}
}

?>