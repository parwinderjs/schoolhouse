<?php 

include_once("config.php");

if(isset($_POST['action'])){
	$conn = connect();
	$topic_id = $_POST['topic_id'];

	$update = "UPDATE `topics` SET `total_views` = `total_views` + 1  WHERE `id` = '$topic_id'";
	mysqli_query($conn, $update);
}

?>