module.exports = require('./build/mediaelementplayer.js');
