<?php 
include_once("config.php");

if(isset($_POST['student_id']) && isset($_POST['topic_id']) && isset($_POST['rating'])){

	$conn = connect();
	$student_id = $_POST['student_id'];
	$topic_id = $_POST['topic_id'];
	$rating = $_POST['rating'];

	if(isAlreadyRated($conn, $student_id, $topic_id)){
		$update = "UPDATE `feedback` SET `rating` = '$rating' WHERE `student_id` = '$student_id' AND `topic_id` = '$topic_id'";
		mysqli_query($conn, $update);
		if(mysqli_affected_rows($conn)>0){
			echo "updated";
		}else{
			echo "error";
		}
	}else{
		$insert = "INSERT INTO `feedback` (`student_id`, `topic_id`, `rating`) VALUES ('$student_id', '$topic_id', '$rating')";
		mysqli_query($conn, $insert);
		if(mysqli_affected_rows($conn)>0){
			echo "rated";
		}else{
			echo "error";
		}
	}
}

function isAlreadyRated($conn, $student_id, $topic_id){
	$select = "SELECT * FROM `feedback` WHERE `student_id` = '$student_id' AND `topic_id` = '$topic_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		if(mysqli_num_rows($result)>0){
			return true;
		}
	}else{
		return false;
	}
}

?>
