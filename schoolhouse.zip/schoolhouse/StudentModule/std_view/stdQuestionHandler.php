<?php
session_start();
include_once("config.php"); 
if(isset($_POST['question'])){
	$question = $_POST['question'];
	$student_id = $_SESSION['std_id'];
	$topic_id = $_POST['topic_id'];

	$conn = connect();
	if($conn){
		$insert = "INSERT INTO `questions`(`question`,`student_id`, `topic_id`) VALUES ('$question', '$student_id', '$topic_id')";
		mysqli_query($conn, $insert);
		if(mysqli_affected_rows($conn) > 0){
			$response = "Sucessfully sent";
		}
	}else{
		$response = "Enable to connect";
	}
	echo $response;
}
?>