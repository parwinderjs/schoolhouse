<!DOCTYPE html>
<html>
<head>
	<title>CourseContent</title>
	<link rel="stylesheet" href="css/bootswatch.min.css">
</head>
<body>
<?php 
include_once("config.php");
if(isset($_POST['submit'])){
	$chapter_id = $_POST['chapter_id'];
	//validating $chapter_id is pending
	$conn = connect();
	$select = "SELECT * FROM `topics` WHERE `chapter_id` = '$chapter_id'";
	$result = mysqli_query($conn, $select);
}
?>

<div class="container">
<div class="page-header">
<h1>Topics</h1>
</div>
<?php 
	if($result){
		if(mysqli_num_rows($result) == 0){
			echo "No topics added to this chapter";
		}else{
		while($row = mysqli_fetch_assoc($result)){

			$topic_name = $row['topic_name'];
			echo "<div class='img-thumbnail'>";
			echo "<a href='VideoPlayer.php?video=".$row['id']."'>";
			if(file_exists("../../TeacherModule/View/Files/".$topic_name.".jpg")){
				$source = "../../TeacherModule/View/Files/".$topic_name.".jpg";
				echo "<img src=$source class='img-thumbnail' alt='play' width='246' height='200'>";
			}else{
			echo "<img src='img/play3.png' class='img-thumbnail' alt='play' width='200' height='200'>";
			}
			echo "</a>";
			echo "<p>".$topic_name."</p>";
			echo "</div>";	
			}
		}	
	} 
	mysqli_close($conn);
 ?>
</div>
</body>
</html>