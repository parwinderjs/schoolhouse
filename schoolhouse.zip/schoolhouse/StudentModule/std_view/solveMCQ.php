<?php 
 session_start();
    if(isset($_SESSION['std_username'])){
    $std_username = $_SESSION['std_username'];
    $std_id = $_SESSION['std_id'];
    }else{
    	header('Location: ./NotLogedIn.html');
    }


if(isset($_GET['id']) || isset($_POST['topic_id'])){
	$topic_id = $_GET['id'];
}else{
	echo "Topic not mentioned";
	exit;
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Solve MCQ</title>

	<link rel="stylesheet" href="../jquery-ui/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script src="../jquery-ui/jquery-ui.min.js"></script>
</head>
<body>
<div class="container">
<div class="page-header">
	<h1>Solve MCQ</h1>
</div>
<?php  
include_once("config.php");
$conn = connect();

function getQuestions($conn, $topic_id){
	$select = "SELECT * FROM `mcq` WHERE `topic_id` = '$topic_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		if(mysqli_num_rows($result)>0){
			echo "<label class='label label-info'>Total Questions: ".$count = mysqli_num_rows($result);
			echo "</label><br><br>";
			$question_no = 1;
			echo "<form method='post' action='checkMCQ.php'>";
			echo "<input type='hidden' name='topic_id' value=$topic_id><div class='panel-group panel-primary'>";
			while($row = mysqli_fetch_assoc($result)){
				$question_id = $row['id'];
				$question = $row['question'];
				$option1 = $row['option1'];
				$option2 = $row['option2'];
				$option3 = $row['option3'];
				$option4 = $row['option4'];
				$correct_option = $row['correct_option'];

				echo "<div class='panel-heading'>Question $question_no : ".$question."</div>
				<div class='panel-body'>
				<input type='radio' name=$question_id value='1'>".$option1."<br>
				<input type='radio' name=$question_id value='2'>".$option2."<br>
				<input type='radio' name=$question_id value='3'>".$option3."<br>
				<input type='radio' name=$question_id value='4'>".$option4."<br></div>";
				$question_no++;
			}
			echo "</div>";
			echo "<input type='submit' name='submit' value='Check' class='btn btn-primary'>";
			echo "</form>";
			echo "<div class='panel-footer'></div>";
		}else{
			echo "<h4>No MCQ's for this topic has been added.</h4>";
		}
	}
}

getQuestions($conn, $topic_id);
?>
</div>
</body>
</html>
