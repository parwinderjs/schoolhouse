<?php

session_start();
if(!isset($_SESSION['std_username'])){
        header("location:NotLogedIn.html");
}else{
$username = $_SESSION['std_username'];
$student_id = $_SESSION['std_id'];
}

include_once('config.php');
$conn = connect(); 

function getCourseJoined($conn, $student_id){
	$select = "SELECT * FROM `joined` WHERE `student_id` = '$student_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		return $result;
	}else{
		return false;
	}
}

function displayCourseJoined($conn, $result){
	if($result){
		while($row = mysqli_fetch_assoc($result)){
			$course_id = $row['course_id'];
     		getCourseDetail($conn, $course_id);
		}	
	}else{
		echo "No joined Course";
	}
}

function getCourseDetail($conn, $course_id){
	$select = "SELECT * FROM `courses` WHERE `id` = '$course_id'";
	$result = mysqli_query($conn, $select);
	$row = mysqli_fetch_assoc($result);
	echo "<div class='panel panel-default'>";
     echo "<div class='panel-heading'>"; 	
     echo "<h4 class='panel-title'>";
     echo "<a data-toggle='collapse' data-parent='#accordion' href='#collapse".$row['id']."'>".$row['course_name']."</a>";
     echo "</h4>";
     echo "</div>";
     echo "<div id='collapse".$row['id']."' class='panel-collapse collapse in'><div class='panel-body'>";
     echo $row['detail'];
     echo "<br /><br/>";
     selectChapters($row['id'], $conn);
     checkForNew($conn, $course_id, $row['course_name']);
     echo "</div></div></div>";

}

function checkForNew($conn, $course_id, $course_name){
    $select = "SELECT * FROM `topics` WHERE `course_id` = '$course_id' AND `timeadded` > (NOW() - INTERVAL 5 DAY)";
    $result = mysqli_query($conn, $select);
    if($result){
        if(($count = mysqli_num_rows($result)) > 0){
            echo "<form method='post' action=updateViewer.php style='float: right'>";
            echo "<input type='hidden' value=$course_id name='course_id'>
            <input type='hidden' value=$course_name name='course_name'>
            <input type='submit' value='new' class='btn btn-primary btn-xs'><span class='badge'>$count</span>";
            echo "</form>";
        }
    }
}

function selectChapters($course_id, $conn){
    $query = "SELECT * FROM `chapters` WHERE chapters.course_id = '$course_id'";
    $result = mysqli_query($conn, $query)  or mysqli_error($conn);
    if($result){
      if(mysqli_num_rows($result) == 0){
        echo "&nbsp&nbsp<i>Null</i>";
      }else{
        echo "&nbsp<form method='post' action='TopicShow.php' class='form-inline'><label class='control-label'>Select Chapter &nbsp</label><select name='chapter_id'>";
        while($chapter = mysqli_fetch_assoc($result)){
        echo "<option value='".$chapter['id']."'>";
        echo $chapter['chapter_name'];
        echo "</option>";
        }
        echo "</select>&nbsp<button type='submit' name='submit' class='btn btn-default btn-xs'>GO</button></form>";
      }
    }  
 }

?>
<!DOCTYPE html>
<html>
<head>
	<title>Your joined courses</title>
	<link rel="stylesheet" href="css/cerulean.min.css">
</head>
<body>
<div class="container">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../studentPanel.php">Home</a></li>
            <li><a href="./CourseDetail.php">Search Courses</a></li>
            <li class="active"><a href="./CourseJoined.php">Joined courses<?php //if($update){ echo "&nbsp<span class='badge'>$update</span>";} ?></a></li>
            <li><a href="./bookmarks.php">Bookmarks</a></li>
            <li><a href="./QuestionsView.php">Questions</a></li>
            <li><a href="../student_level-1/stdInteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $username; ?></a></li>
                <li><a href="../Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<!--nav end -->    
<br>

    <div class="jumbotron" style="text-align: center;">
        <h1>JOINED COURSES</h1>
    </div>
<?php 
$result = getCourseJoined($conn, $student_id);
displayCourseJoined($conn, $result); 
?>
</div>
</body>
</html>