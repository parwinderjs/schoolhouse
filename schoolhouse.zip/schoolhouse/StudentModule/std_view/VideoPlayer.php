<?php 
	
	include_once("config.php"); 
    session_start();
    if(isset($_SESSION['std_id'])){
    $std_id = $_SESSION['std_id'];
	}else{
		header("Location:../NotLogedIn.html");
	}
?>
<?php 
if(isset($_GET['video'])){
	$topic_id = intval($_GET['video']);
}else{
	echo "Error loading video";
	exit;
}

$conn = connect();

function topicInfo($conn, $topic_id){
	if($conn){
		$select = "SELECT * FROM `topics` WHERE `id` = '$topic_id'";
		$result = mysqli_query($conn, $select);
		$row = mysqli_fetch_assoc($result);
		if($result){
			$info = array('topic_name' => $row['topic_name'], 'total_views' => $row['total_views']);
			return $info;
		}else{
		return "Not available";
		}
	}
}

$topic_info = topicInfo($conn, $topic_id);
$topic_name = $topic_info['topic_name'];
$total_views = $topic_info['total_views'];

function topicAuthor($conn, $topic_id){
	if($conn){
		$select = "SELECT * FROM `teachers` WHERE `id` = (SELECT `teacher_id` FROM `courses` WHERE `id` = (SELECT `course_id` FROM `chapters` WHERE `id` = (SELECT `chapter_id` FROM `topics` WHERE `id` = '$topic_id')))";
		$result2 = mysqli_query($conn, $select) or die(mysqli_error($conn));
		if($result2){
			$row = mysqli_fetch_assoc($result2);
			return $row['first_name']." ".$row['last_name']; 
		}else{
			return "Not available";
		}
	}
}

$topic_author = topicAuthor($conn, $topic_id);

function topicCourse($conn, $topic_id, $bool = false){
	if($conn){
		$select = "SELECT * FROM `courses` WHERE `id` = (SELECT `course_id` FROM `chapters` WHERE `id` = (SELECT `chapter_id` FROM `topics` WHERE `id` = '$topic_id'))";
		$result = mysqli_query($conn, $select);
		if($result){
			$row = mysqli_fetch_assoc($result);
			if($bool){
				return $row['id'];
			}else{
				return $row['course_name'];	
			}
		}else{
			return "Not available";
		}
	}
}

$topic_course = topicCourse($conn, $topic_id);
$topic_course_id = topicCourse($conn, $topic_id, true);

function topicChapter($conn, $topic_id){
	if($conn){
		$select = "SELECT * FROM `chapters` WHERE `id` = (SELECT `chapter_id` FROM `topics` WHERE `id` = '$topic_id')";
		$result = mysqli_query($conn, $select);
		if($result){
			$row = mysqli_fetch_assoc($result);
			return $row['chapter_name'];
		}else{
			return "Not available";
		}
	}
}

$topic_chapter = topicChapter($conn, $topic_id);

function isJoined($conn, $course_id){
	if($conn){
		$select = "SELECT * FROM `joined` WHERE `course_id` = '$course_id'";
		$result = mysqli_query($conn, $select);
		
		if(mysqli_num_rows($result) > 0){
			return true;
		}else{
			return false;
		}
	}
}

$is_joined = isJoined($conn, $topic_course_id);
?>
<!DOCTYPE html>
<html>
<head>
	<title>VideoPlayer</title>
	<!--link rel="stylesheet" href="css/bootswatch.min.css"-->
	<link rel="stylesheet" href="css/cerulean.min.css">
	<link rel="stylesheet" href="css/bars-pill.css">
	<link rel="stylesheet" href="jquery-ui/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="VideoPlayer.css">
  	<script src="js/jquery.min.js"></script>
  	<script src="js/jquery-ui.min.js"></script>
  	<!--<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>-->

		<!-- for rating bar -->
		<script src="js/jquery.barrating.js"></script>
		<script src="js/selectRating.js"></script>
</head>
<script>
var g_topic_id = <?php echo "\"".$topic_id."\""; ?> ;
var g_std_id = <?php echo "\"".$std_id."\""; ?>;
var g_course_id = <?php echo $topic_course_id; ?>;

var is_joined = <?php if($is_joined){echo "true";}else{echo "false";} ?>;
$(document).ready(function(){
	if(is_joined){
		$("#join").addClass("joined").html("JOINED");
	}

	$("#join").click(function(){
		$("#join").toggleClass("joined");
		var buttonclass = $(this).attr("class");
		console.log(buttonclass);
		if(buttonclass == "button joined"){
			$.ajax({
				url: "JoinHandler.php",
				method: "post",
				data: {
					"action": "add",
					"student_id": g_std_id,
					"course_id": g_course_id
				},
				success: function(result, status){
					var response = result;
					console.log(response);
					if(response){
					$("#join").html("JOINED");
					}
				}
			});
			
		}else if(buttonclass == "button"){
			$.ajax({
				url: "JoinHandler.php",
				method: "post",
				data: {
					"action": "delete",
					"student_id": g_std_id,
					"course_id": g_course_id
				},
				success: function(result, status){
					var response = result;
					if(response){
						$("#join").html("JOIN");
					}
				}
			});
			
		}
	});
});
</script>

<script>
$(document).ready(function(){
	$("#submit").click(function(){
		var question = $("#question").val();
		if(question.length == 0){
			return;
		}
		console.log(question);
		$.ajax({
			url:"stdQuestionHandler.php",
			method:"post",
			data: { "question" : question,
				  "student_id" : g_std_id,
				  "topic_id" : g_topic_id
					},
			success: function(result, status){
			var response = result;
			console.log(status + result);
			$("#question").val('');
		}		
		});
	});	
});
</script>
<body style="background-color: black">
<div class="container" style="background-color: lightgrey">
<div class="page-header">
<h1><?php echo $topic_name; ?></h1>
</div>
<div class="container col-md-8 col-sm-8">
 <video class="col-md-12" id='topic_video'controls autoplay>
  <source src="mp4.php?video=<?php echo $topic_id ?>" type="video/mp4">
</video>

<script>
$(function(){
	var g_duration_time = 0;
	var g_fomated_duration_time = 0;
	var g_pre_current_time = 0;
	var g_added = false;

  	$("#topic_video").on(
    	"timeupdate", 
    	function(event){
      		var currentTime = this.currentTime;

      		var gap = currentTime - g_pre_current_time;
      														// currentTime from prev current time

			if(currentTime > g_pre_current_time + 2 || currentTime < g_pre_current_time - 2){
      			g_duration_time = 0;
      			g_pre_current_time = this.currentTime;
			}else{
      			g_duration_time = g_duration_time + gap;
      			g_pre_current_time = this.currentTime;
      		}

      		var minutes = parseInt(g_duration_time/60, 10);
      		var seconds = parseInt(g_duration_time % 60,10);
      		g_fomated_duration_time = minutes + ":" + seconds;
			console.log("Total duration : " + g_fomated_duration_time);

			if(minutes == 1){
				if(!g_added){
					g_added = true;
					$.ajax({
						url:"updateTotalView.php",
						method:"post",
						data: { "action" : "update",
							  "student_id" : g_std_id,
							  "topic_id" : g_topic_id
							   },
						success: function(result, status){
							//alert("Video added to viewed");
						}		
					});
					
				}
			}
    });
});

</script>



</div><div class="col-md-4 col-sm-4 well white" id="info">
	<p><b>Topic Name</b>: <?php echo $topic_name; ?></p>
	<p><b>Author</b>: <?php echo $topic_author; ?> </p>
	<p><b>Chapter</b>: <?php echo $topic_chapter; ?> </p>
	<p><b>Course</b>: <?php echo $topic_course; ?> </p>
	<p><b>Total views</b>: <?php echo $total_views; ?> </p>
</div>
<div style="clear:both"></div><br>
<div class="well col-md-12 col-sm-12" style="background-color: white;">

<div class="col-md-3"><b>How much(%) it helped?</b>
						<select id="rating-pill" name="rating">
							<option value="0">0</option>
							<option value="1">20</option>
							<option value="2">40</option>
							<option value="3">60</option>
							<option value="4">80</option>
							<option value="5">100</option>
						</select>
</div><br>

<?php  
	function isAlreadyRated($conn, $student_id, $topic_id){
		$select = "SELECT * FROM `feedback` WHERE `student_id` = '$student_id' AND `topic_id` = '$topic_id'";
		$result = mysqli_query($conn, $select);
		if($result){
			if(mysqli_num_rows($result)>0){
				$row = mysqli_fetch_assoc($result);
				return $row['rating'];
			}
		}else{
			return false;
		}
	}

	$initial_rating = null;
	if($rating = isAlreadyRated($conn, $std_id, $topic_id)){
			$initial_rating = $rating;
	}else{
			$initial_rating = -1;
	}
?>
<script>
 var g_initial_rating = <?php echo $initial_rating; ?>;
</script>

<div class="col-md-4">
<div role="button" id="join" class="button" style="margin-left: 5%">JOIN</div>

<?php  
	function checkBookmark($conn, $topic_id, $student_id){
			$select = "SELECT * FROM `bookmarked` WHERE `student_id` = '$student_id' AND `topic_id` = '$topic_id'";
			$result = mysqli_query($conn, $select);
			if($result){
				if(mysqli_num_rows($result)>0){
					echo "<div id='bookmark' class='btn btn-primary'>Remove bookmark</div>";
				}else{
					echo "<div role='button' id='bookmark' class='btn btn-primary'>Add to</div>";
				}
			}
	}

	checkBookmark($conn, $topic_id, $std_id);
?>
 

<!-- save to bookmark folder -->
<div id="dialog" title="Bookmark">
  <legend></legend>
  <label>Select Folder</label>
  <select id='select_folder' name="folder">


<?php
  	function getFolders($conn, $student_id){
  		$select = "SELECT * FROM `bookmark_folders` WHERE `student_id` = '$student_id'";
  		$result = mysqli_query($conn, $select);
  		if($result){
  			if(mysqli_num_rows($result) >0){
  				while($row = mysqli_fetch_assoc($result)){
  					echo "<option value='".$row['folder_name']."'>".$row['folder_name']."</option>";
  				}
  			}else{
  				return;
  			}
  		}else{
  			echo "Not avialabe";
  		}
  	}

  	getFolders($conn, $std_id);
?>


  </select>
  <button id='save'>Save</button>
  <button id="new">Create Folder</button>
</div>
<!--				end					-->

<div id="new_dialog" title="Create Folder">
	<legend></legend>
	<label>New Folder</label>
	<input id="folder_name"/>
	<center><button id="create">Create</button></center>
</div>                           
</div>
<div id="mcq" class="btn btn-link" style="float: right;">Try MCQ</div>
<div style="clear: both"></div>
<script>
	$(document).ready(function(){

		var button = $("#bookmark");
		var dialog = $("#dialog").dialog({
			autoOpen: false,
    		show: 'blind',
    		draggable: false,
            resizable: false,
            closeText: "hide",
    		position: { my: 'left top', at: 'left bottom', of: button }
    	});	

    	var new_dialog = $("#new_dialog").dialog({
			autoOpen: false,
    		show: 'blind',
    		draggable: false,
            resizable: false,
            closeText: "hide",
    		position: { my: 'left top', at: 'left bottom', of: button }
    	});	

		$("#bookmark").click(function(e){
			if($(this).html() == "Add to"){
				var isOpen = dialog.dialog( "isOpen" );
				console.log(isOpen);
				if(isOpen){
					dialog.dialog('close');
				}else{
					dialog.dialog('open');		
				}
			}else if($(this).html() == "Remove bookmark"){
				$.ajax({
					url: "removeBookmark.php",
					method:"post",
					data: {
						"std_id" : g_std_id,
						"topic_id":g_topic_id
					},
					success: function(result, status){
							$("#bookmark").html("Add to");
							console.log(result);
					}
					});
			}	
		});


		$("#new").click(function(e){	
				dialog.dialog('close');
				var isOpen = new_dialog.dialog( "isOpen" );
				console.log(isOpen);
				if(isOpen){
					new_dialog.dialog('close');
				}else{
					new_dialog.dialog('open');		
				}
		});

		$("#create").click(function(e){
				var folder_name = $("#folder_name").val();
				$.ajax({
					url: "createFolder.php",
					method:"post",
					data: {
						"folder_name":folder_name,
						"std_id" : g_std_id
					},
					success: function(result, status){
						if(result === "false"){
							return;
						}else{
						new_dialog.dialog('close');
						$("#select_folder").append("<option>" + result + "</option>");
						dialog.dialog('open');
						}
					}
				});
		});

		$("#save").click(function(){
				var to = $("#select_folder").val();
				if(to.length < 1){ return;}else{
					$.ajax({
					url: "saveBookmark.php",
					method:"post",
					data: {
						"std_id" : g_std_id,
						"topic_id":g_topic_id,
						"folder_name":to,
					},
					success: function(result, status){
						if(result == "added"){
							dialog.dialog('close');
							$("#bookmark").html("Remove bookmark");
						}
						console.log(result);
					}
					});
				}
		});

		$("#mcq").click(function(){window.open("./solveMCQ.php?id=" + g_topic_id)});
});		
</script>

<br/><br/><br/>
<br/>
<div class="col-md-8">
<textarea id="question" placeholder="Write to ask any question" style="width:90%; margin-left: 1%"></textarea><br/>
<button class="btn btn-primary" id="submit" style="margin-left: 1%">Send</button>
</div>
</div>
<div class="well col-md-12 col-sm-12" style="background-color: white;">
<h4>Related Asked Questions</h4>
<?php

function getRelatedAnswer($conn, $topic_id){
	$select = "SELECT * FROM `answers` WHERE `visibility` = 'public' AND `topic_id` = '$topic_id'";
	$result = mysqli_query($conn, $select);
	 if($result){
	 	if(mysqli_num_rows($result) == 0){ echo "No questions";}
		while($row = mysqli_fetch_assoc($result)){
			echo "<br>Q:".getQuestion($conn, $row['question_id'])."<br>";
			echo "<br>Ans:".$row['answer']."<br>";
		}
	}else{
			return "Not available";
	}
}

function getQuestion($conn, $question_id){
	$select = "SELECT * FROM `questions` WHERE `id` = '$question_id'";
	$result = mysqli_query($conn, $select);
	if($result){
			$row = mysqli_fetch_assoc($result);
			return	$question = $row['question'];
	}else{
			return "Not available";
	}
}

getRelatedAnswer($conn, $topic_id);
?>
</div>
</div>
</body>
</html>