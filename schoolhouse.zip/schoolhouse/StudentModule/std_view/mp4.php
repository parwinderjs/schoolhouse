<?php 
include_once("config.php");
if(isset($_GET['video'])){
    $topic_id = intval($_GET['video']);
    $conn = connect();
    $select = "SELECT `content` FROM `topics` WHERE `id` = '$topic_id'";
    $result = mysqli_query($conn, $select);
    if($result){
        $row = mysqli_fetch_assoc($result);
        $file = "../../TeacherModule/View/".$row['content'];                        // path from student folder
        $newfile = 'outFile';
        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename='.basename($newfile));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();
            flush();
            readfile($file);
            exit;
        }
    }else {
        exit;
    }
}
?>