<?php 
session_start();
if(session_destroy()){ 			// is all session destroyed
	echo "You are loged out";
	header("location:../front.php"); // redirect to front page
}

?>