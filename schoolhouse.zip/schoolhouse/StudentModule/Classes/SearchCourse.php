<?php

include_once("Database.php");  

class Search {
	public $php_self;
	public $total_course;
	public $pages_required;
	public $limit;
	public $current_page = 1;
	public $links_limit = 5;
	public $select;
	public $append;
	private $conn;

	function __construct($query, $limit, $keyword){
		$this->limit = $limit;
		$db = new Database();							// for database connection
		$this->conn = $db->getConnection();
		$this->select = $query;
		$this->getTotal();
		$this->pages_required = ceil($this->total_course/$this->limit);
		$this->php_self = htmlspecialchars($_SERVER['PHP_SELF'] );					// required for pagination links
		if (isset($_GET['page'] )) {
			$this->current_page = intval($_GET['page'] );
		}
		if(!empty($keyword)){
			$this->append = "keyword=".$keyword;
		}
	} 	

	function getTotal(){
		$result = mysqli_query($this->conn, $this->select);
		if($result){
			$this->total_course = mysqli_num_rows($result);
		}else{
			return false;
		}
	}

	/*get limited result*/
	function getPageResult(){
		if($this->current_page < 1 || $this->current_page > $this->pages_required){
			return false;
		}else{
		$offset = ($this->current_page-1)*$this->limit;
		$query = $this->select. " LIMIT {$offset}, {$this->limit}";
		$result = mysqli_query($this->conn, $query);
		if($result){
			return $result;
		}else{
			mysqli_error($this->conn);
		}
		}
	}

//--------------------------------------------------------pagination links work----------------------------------------------
	function renderFirst($tag = 'First') {
		if ($this->total_course == 0)
			return false;
		
		if ($this->current_page == 1) {									// if it is already first
			return '<li><span>'.$tag.'</span></li>';
		} else {
			return '<li><a href="' . $this->php_self . '?page=1&' . $this->append . '">' . $tag . '</a></li> ';
		}
	}

	function renderLast($tag = 'Last') {
		if ($this->total_course == 0)
			return false;
		
		if ($this->current_page == $this->pages_required) {				// if it is last
			return '<li><span>'.$tag.'<span></li>';
		} else {
			return '<li><a href="' . $this->php_self . '?page=' . $this->pages_required . '&' . $this->append . '">' . $tag . '</a></li>';
		}
	}

	function renderNext($tag = '&gt;&gt;') {
		if ($this->total_course == 0)
			return false;
		
		if ($this->current_page < $this->pages_required) {
			return '<li><a href="' . $this->php_self . '?page=' . ($this->current_page + 1) . '&' . $this->append . '">' . $tag . '</a></li>';
		} else {
			return '<li><span>'.$tag.'</span></li>';
		}
	}

	function renderPrev($tag = '&lt;&lt;') {
		if ($this->total_course == 0)
			return false;
		
		if ($this->current_page > 1) {
			return '<li><a href="' . $this->php_self . '?page=' . ($this->current_page - 1) . '&' . $this->append . '">' . $tag . '</a></li>';
		} else {
			return '<li><span>'.$tag.'</span></li>';
		}
	}

	function renderNav() {
		if ($this->total_course == 0)
			return false;
		
		$batch = ceil($this->pages_required / $this->links_limit );						// no. of navigation links per each page
		$end = $batch * $this->links_limit;												// because total number integer is also last one

		// $start is start of each batch
		// $end is end of each batch

		if ($end == $this->current_page) {												// ????
			$end = $end + $this->links_limit - 1;
		    $end = $end + ceil($this->links_limit/2);
		}
		if ($end > $this->pages_required) {
			$end = $this->pages_required;
		}

		$start = $end - $this->links_limit + 1;
		$links = '';
		
		for($i = $start; $i <= $end; $i ++) {
			if ($i == $this->current_page) {
				if($i > 0){
				$links .= '<li><span>'.$i.'</span></li>';}
			} else {
				if($i >0){
				$links .= '<li><a href="' . $this->php_self . '?page=' . $i . '&' . $this->append . '">' . $i . '</a></li>';
				}
			}
		}
		
		return $links;
	}

	function renderFullNav() {
		return $this->renderFirst() . '&nbsp;' . $this->renderPrev() . '&nbsp;' . $this->renderNav() . '&nbsp;' . $this->renderNext() . '&nbsp;' . $this->renderLast();
	}
		
}
?>
