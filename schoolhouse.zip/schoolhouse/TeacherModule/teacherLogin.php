<?php 
 session_start();
 ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" href="css/cerulean.min.css">
	<style>
		.error{
			color : #FF0000;
		}
	</style>
</head>
<body>
<?php 
include "teacherLoginHandler.php";
 ?>
<div class="container">
	<br /><br /><br /><br />
	<div class="container">
	<div class="panel panel-primary col-md-4 col-md-offset-4"><br />
		<div class="panel-heading">
			<h1 class="panel-title">Login as teacher</h1>
		</div>
		<div class="panel-body">
			<form method="post">
			<div class="form-group">
			<legend>Email</legend>
			<input type="email" name="email" class="form-control" placeholder="registerd email" />
			<span class='error'><?php echo $email_error; ?></span>
			</div>
			<legend>Password</legend>
			<input type="password" name="password" class="form-control" placeholder="Password" />
			<span class='error'><?php echo $password_error; ?></span>
			<br />
			<input type="submit" name="submit" value="Login" class="btn btn-primary btn-block" />
			</form>
		</div>
	</div>
	</div>
</div>
<?php
	ob_flush();
?>
</body>
</html>