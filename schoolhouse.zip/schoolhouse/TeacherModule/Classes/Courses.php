<?php 
	require_once("Chapters.php");
	// a single course
	class Course {
		public $course_name;
		public $total_chapters;
		public $course_id;
		public $chapter; 					// holds every chapter of this course
		private $conn;


		function __construct($name){
			$this->course_name = $name;
			$database = new Database();
			$this->conn = $database->getConnection();
			// ------------------set course_id
								$select = "SELECT `id` FROM `courses` WHERE `course_name` = '$this->course_name'";
								$result = mysqli_query($this->conn, $select);
								$row = mysqli_fetch_assoc($result);
								$this->course_id = $row['id'];
		}

		function showChapters(){
			//fetch from database;
			$select = "SELECT * FROM `chapters` WHERE chapters.id = '$this->course_id'";
			$result = mysqli_query($this->conn, $select);
			return $result;
		}

		function selectChapter($name, $teacher_id){
			return $chapter = new Chapter($name, $teacher_id);
		}

		function addChapter($name){
			$insert = "INSERT INTO `chapters`(`chapter_name`,`course_id`) VALUES ('$name','$this->course_id')";
			mysqli_query($this->conn, $insert);
			if(mysqli_affected_rows($this->conn)>0){
				echo "Chapter created";
			}else {
				echo "error creating chapter".mysqli_error();
			}

		}

		function deleteChapter($name){

		}
	}
?>