<?php  

	include_once("Database.php");

	class Chapter {
		public $chapter_name;
		public $total_topics;
		public $course_id;
		public $chapter_id;
		public $teacher_id;
		private $conn;

		function __construct($name, $teacher_id){
			$this->chapter_name = $name;
			$this->teacher_id = $teacher_id;
			$db = new Database();
			$this->conn = $db->getConnection();
			$select = "SELECT * FROM `chapters` WHERE `chapter_name` = '$this->chapter_name'";
			$result = mysqli_query($this->conn, $select);
			if($result){
				$row = mysqli_fetch_assoc($result);
				$this->chapter_id = $row['id'];
				$this->course_id = $row['course_id'];
			}else{
				echo "Error while setting chapter id : ".mysqli_error();
			}
		}

		function showTopics(){
			$select = "SELECT * FROM `topics` WHERE '$this->chapter_id' = topics.chapter_id";
			return $result = mysqli_query($this->conn, $select);
			//fetch from database
			// return $result
		}

		function addTopic($name, $file_path){
			$chapter_id = $this->chapter_id;
			$insert = "INSERT INTO `topics` (`topic_name`, `content`, `chapter_id`, `course_id`, `teacher_id`) VALUES ('$name', '$file_path', '$chapter_id','$this->course_id', '$this->teacher_id')";
			$result = mysqli_query($this->conn, $insert);
			if(mysqli_affected_rows($this->conn)>0){
				$topic_id = mysqli_insert_id($this->conn);
				$this->updateStudentsJoined($this->conn, $topic_id);
				return true;
			}else{
				echo mysqli_error($this->conn);
			}
		}

		function updateStudentsJoined($conn, $topic_id){
			$append = ",".$topic_id;
			$update = "UPDATE `joined` SET `newtopic` = CONCAT(IFNULL(`newtopic`,''),'$append') WHERE `course_id` = $this->course_id";
			$result = mysqli_query($conn, $update);
			if(mysqli_affected_rows($conn)>0){
				//echo "Updated";
			}else{
				//echo "Error";
			}
		}

		function deleteTopic($name){
			
		}
	}
?>