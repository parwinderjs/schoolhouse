<?php
 
class Search {
	public $php_self;
	public $total_course;
	public $pages_required;
	public $limit;
	public $current_page = 1;
	public $links_limit = 5;
	public $select;
	public $append;
	private $conn;

	function __construct($conn, $query, $limit){
		$this->limit = $limit;
		$this->conn = $conn;
		$this->select = $query;
		$this->getTotal();
		$this->pages_required = ceil($this->total_course/$this->limit);
		$this->php_self = htmlspecialchars($_SERVER['PHP_SELF'] );
		if (isset($_GET['page'] )) {
			$this->current_page = intval($_GET['page'] );
		}
	} 	

	function getTotal(){
		$result = mysqli_query($this->conn, $this->select);
		if($result){
			$this->total_course = mysqli_num_rows($result);
		}else{
			return false;
		}
	}

	function getPageResult(){
		if($this->current_page < 1 || $this->current_page > $this->pages_required){
			return false;
		}else{
		$offset = ($this->current_page-1)*$this->limit;
		$query = $this->select. " LIMIT {$offset}, {$this->limit}";
		$result = mysqli_query($this->conn, $query);
		if($result){
			return $result;
		}else{
			mysqli_error($this->conn);
		}
		}
	}

	function displayFirst($tag = 'First') {
		if ($this->total_course == 0)
			return false;
		if($this->current_page != 1){
			$first = 1;
			return '<li><a href="' . $this->php_self . '?page=$first&' . $this->append . '">' . $tag . '</a></li> ';
		}
	}

	function displayLast($tag = 'Last') {
		if ($this->total_course == 0)
			return false;

		$total_page = $this->pages_required;
		if($this->current_page != $total_page){
			$last = $total_page;
			return '<li><a href="' . $this->php_self . '?page=' . $last . '&' . $this->append . '">' . $tag . '</a></li>';
		}
	}

	function displayNext($tag = '&gt;&gt;') {
		if ($this->total_course == 0)
			return false;

		$total_page = $this->pages_required;
		if($this->current_page > 0 && $this->current_page < $total_page){
			$next = $this->current_page+1;
			return '<li><a href="' . $this->php_self . '?page=' .$next. '&' . $this->append . '">' . $tag . '</a></li>';
		}else{
			return "<li><span style='cursor:pointer'>".$tag."</span></li>";
		}
	}

	function displayPrev($tag = '&lt;&lt;') {
		if ($this->total_course == 0)
			return false;
		
		$total_page = $this->pages_required;
		if($this->current_page > 1){
			$prev = $this->current_page - 1;
			return '<li><a href="' . $this->php_self . '?page=' . ($this->current_page - 1) . '&' . $this->append . '">' . $tag . '</a></li>';
		}else{
			return "<li><span style='cursor:pointer'>".$tag."</span></li>";	
		}	
	}

	function displayNav($prefix = '', $suffix = '') {
		if ($this->total_course == 0)
			return false;
		$current_page = $this->current_page;
		$limit = $this->links_limit;
		$current_page = ($current_page > 0)? $current_page : 1;	
		$start = $current_page;  
		$end = $current_page + ($limit -1);
		$total_page = $this->pages_required;
		if($end > $total_page){
			unset($start);
			$start = ((($total_page - $limit) + 1) > 0)? ($total_page - $limit) + 1 : 1;			// check for $start being negative
			unset($end);
			$end = $total_page;				
		}
		$links = '';
		for($i = $start; $i <= $end; $i ++) {
			if($i == $this->current_page){													// act as disabled link for current page
				$links .= "<li><span style='cursor:pointer'>".$prefix . $i . $suffix."</span></li>";
			}else{
				$links .= '<li>' . $prefix . '<a href="' . $this->php_self . '?page=' . $i . '&' . $this->append . '">' . $i . '</a>' . $suffix . '</li>';
			}
		}
		return $links;
	}

	function displayFullNav() {
		return $this->displayFirst() . '&nbsp;' . $this->displayPrev() . '&nbsp;' . $this->displayNav() . '&nbsp;' . $this->displayNext() . '&nbsp;' . $this->displayLast();
	}
		
}
?>
