<?php 
	require_once("Database.php");
	require_once("Courses.php");

	class Teacher {
		public $teacher_id;
		public $full_name;
		public $username;
		public $total_courses;
		private $conn;
		

		public $error = array();

		function __construct($username){
			if(empty($username)) die("Username Empty");
			$this->username = $username;
			$database = new Database();
			$this->conn = $database->getConnection();

		//--------------------- set teacher id and name----------------------------
			$select = "SELECT `id`,`first_name`,`last_name` FROM `teachers` WHERE `first_name` = '$username'";
			$result = mysqli_query($this->conn, $select);
			
			if(mysqli_num_rows($result) > 0){
				$row = mysqli_fetch_assoc($result);
				$this->teacher_id = $row['id'];
				$this->full_name = $row['first_name']." ".$row['last_name'];
			}else { 
				$error[] = "Error setting teacher_id"; 
			}
		}

		function showCourses(){
			$select = "SELECT * FROM `courses` WHERE courses.teacher_id = '$this->teacher_id'";
			$result = mysqli_query($this->conn, $select);
			return $result;
		}

		function selectCourse($course_name){
			return $course = new Course($course_name);
		}

		function addCourse($name, $detail){
			$insert = "INSERT INTO `courses`(`course_name`, `detail`, `teacher_id`) VALUES ('$name', '$detail', '$this->teacher_id')";
			mysqli_query($this->conn, $insert);
			if(mysqli_affected_rows($this->conn) > 0){
				echo "Course Added";
			}else {
				echo "Error Adding course : ".mysqli_error($this->conn);
			}
		}

		function searchCourses($keyword){
			$search = "SELECT * FROM `course` WHERE course.name = '$keyword%'";
		}
		
		function closeTeacher(){
			$this->session = false;
		}
	}

?>