<?php
    session_start();
    if(!isset($_SESSION['username'])){
        header("location:NotLogedIn.html");
    }else{
         $username = $_SESSION['username'];
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Teacher Panel</title>
	<link rel="stylesheet" type="text/css" href="css/bootswatch.min.css">
	<link rel="stylesheet" type="text/css" href="css/simple-sidebar.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="./teacherPanel.php">Home</a></li>
            <li><a href="View/ListOfCourses.php">Manage Courses</a></li>
            <li><a href="View/tchQuestionView.php">Questions</a></li>
            <li><a href="./level-1/InteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $username; ?></a></li>
                <li><a href="Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<div class="jumbotron" style="text-align: center"><h1>WELCOME TEACHER</h1></div>
</div>
</body>
</html>