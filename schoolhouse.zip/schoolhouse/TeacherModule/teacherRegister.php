<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<link rel="stylesheet" type="text/css" href="css/cerulean.min.css">
	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

	<style>
		.error{
			color : #FF0000;
		}
	</style>
</head>
<body>
<?php 
include("teacherRegHandler.php");
?>
<div class="container">

<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container-fluid">
			<a class="navbar-brand">Schoolhouse</a>
			<ul class="nav navbar-nav navbar-right">
				<li>
					<a class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Login
    				<span class="caret"></span></a>
    				<ul class="dropdown-menu">
      				<li><a href="./teacherLogin.php">Teacher</a></li>
      				<li><a href="../StudentModule/studentLogin.php">Student</a></li>
    				</ul>
    			</li>
				<li><a href=#>About</a></li>
			</ul>
		</div>		
</nav>
<br>
<br><br>

	<div class="page-header">
		<h1>Teacher Registeration</h1>
	</div>
	<div class="panel panel-primary">
		<div class="panel-body">
			<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>" >
				<label>First Name</label>
					<span class="error"><?php echo "&nbsp".$first_name_error; ?></span>
				<input type="text" name="first_name" class="form-control" value="<?php echo htmlspecialchars($first_name) ?>" />
				<label>Last Name</label>
					<span class="error"><?php echo "&nbsp".$last_name_error; ?></span>
				<input type="text" name="last_name" class="form-control" value="<?php echo htmlspecialchars($last_name) ?>"></input>
				<label>Email</label>
					<span class="error"><?php echo "&nbsp".$email_error; ?></span>
				<input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email) ?>"></input>
				<label>Password</label>
					<span class="error"><?php echo "&nbsp".$password_error; ?></span>
				<input type="password" name="password" class="form-control"></input>
				<label>Confirm Password</label>
				<input type="password" name="password_check" class="form-control" />
				<br />
				<input type="submit" name="submit" value="Register" class="btn btn-primary btn-block" />
			</form>	
		</div>
	</div>
</div>

</body>
</html>
