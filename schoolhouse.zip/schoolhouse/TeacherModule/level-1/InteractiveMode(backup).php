<?php  
    session_start();
    $username = $_SESSION['username'];
?>

// intended to work upon using 
// var message = { "from": , "to": , "sdp/ice": }
// sending person identity on websocket connection success and store as "connected users"
// create new version of Chat.php for handling this modified things
//works on firefox, audio works, canvas sync works, chat works
// dependency : canvas.js
<!DOCTYPE html>
<html>
<head>
    <title>Working example of audio communcation</title>    
    <meta charset="utf-8">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="./canvas.js"></script>
  <script src="./webrtc.js"></script>
</head>
<script>
    var username = <?php echo "\"".$username."\""; ?>;
    var receiver = null;
$(document).ready(function(){
    
    //checkConnected();
    function checkConnected(){
        //console.log("Checking Database");
        $.ajax({
        url : "checkConnected.php",
        method : "post",
        data : { check : "true",
                 "username" : username
             },
        success : function(result){
            //console.log(result);
            var list = $('ul.connected li');
            var already = new Array();
            if(list.length > 0){
           console.log(list[0].innerText);
                for(var i=0; i < list.length; i++){
                already = [list[i].innerText];                  // each of this user is already displayed 
                }
            }
            connected = JSON.parse(result);                     // result is array encoded in json array
            if(connected.length == 0){$("#connected").html('');}else{
            for(var i = 0; i < connected.length || i == 0; i++){
                //console.log(i);
                if($.inArray(connected[i],already) == -1){      // if this is not in already displayed
                    $("#connected").append("<li>" + connected[i] + "</li>");
                }else{
                    continue;
                }    
            }
            }           
            window.setTimeout(checkConnected, 10000);
        }
        });
    }

    $("#interface").hide();
    $("#controler").click(function(){
        $("#interface").show();
    });

    $("#select").click(function(){
        receiver = $("#receiver").val();
    });
});    
</script>
<style>
#interface {
	display: none;
}
</style>
<body onload="init()">
<h6>Now online</h6>
<button id="controler">Show Interface</button>
<div class="container">
<ul class="connected" id="connected">
</ul>
Connect with : <input type="text" id="receiver"></input><button id="select">Select</button>


</div>
<div class="container" id="interface">
    <div id="canvas-container">
    <canvas id="can" width="700" height="500" style="background-color: lime; float: left"></canvas></div>
        
    <div class="col-md-3 jumbotron" style="height: 300; float:left; overflow: scroll">
        <h6 style="text-align: center">Messges</h6>
        <div id="board"></div>
        <input id="input" type="text"></input>
        <button id="send">Send</button>
    </div>
    <div class="col-md-3">
    <label>Caller</label>
    <audio id="localAudio" class="col-md-12" controls ></audio><br />
    <label>Callee</label>
    <audio id="remoteAudio" class="col-md-12" controls ></audio>
    <button id="call">Call</button>
    </div>
</div>
</body>
</html>
