<?php 
if(isset($_POST['check'])){
	$username = $_POST['username'];
    $conn = mysqli_connect("localhost","root","Akalsahae","schoolhouse");
    $select = "SELECT * FROM `connected` WHERE `name` != '$username'";                         // + add WHERE student is joined with this specific teacher
    $result = mysqli_query($conn, $select);
    $connected = array();
    while($row = mysqli_fetch_assoc($result)){
        $connected[] = $row['name'];    }
        echo json_encode($connected);
}    
?>