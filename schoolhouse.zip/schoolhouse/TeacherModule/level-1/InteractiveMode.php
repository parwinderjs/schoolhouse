<?php  
    session_start();
    if(!isset($_SESSION['username'])){ header("location:../NotLogedIn.html");}
    $username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Teacher Interactive mode</title>    
    <meta charset="utf-8">
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <!--link rel="stylesheet" type="text/css" href="../css/bootswatch.min.css"-->  
<link rel="stylesheet" href="../jquery-ui/jquery-ui.css">

  <script type="text/javascript" src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../jquery-ui/jquery-ui.min.js"></script>
  <script src="./draw_new.js"></script>
  <script src="./webrtc.js"></script>
</head>
<script>
    var g_username = <?php echo "\"".$username."\""; ?>;
    var g_receiver = null;
    var g_local_stream = null;
    var displayed = new Array();
    var g_check_flag;
$(document).ready(function(){
    
    
    
    function checkConnected(){
        //console.log("Checking Database");
        $.ajax({
        url : "checkConnected.php",
        method : "post",
        data : { check : "true",
                 "username" : g_username
             },
        success : function(result){
            connected = JSON.parse(result);                     // result is array encoded in json array
            unique = $.unique(connected);
            //console.log(unique);
            if(unique.length == 0){$("#selectable").html('');}else{
            for(var i = 0; i < unique.length || i == 0; i++){
                //console.log(i);
                if($.inArray(displayed,unique) == -1){      // if this is not in already displayed
                    $("#selectable").append("<li class='ui-widget-content'>" + unique[i] + "</li>");
                    displayed = unique[i];
                }else{
                    continue;
                }    
            }
            }
            if(g_check_flag){           
            window.setTimeout(checkConnected, 10000);           // call again if flag is set
            }
        }
        });
    }

    g_check_flag = true;
    if(g_check_flag){
        checkConnected();              // just to initialize the update mechanism
    }

    $("#interface").hide();

    $("#Go").click(function(e){
        if(g_receiver === null || !g_receiver){ alert("Please select a peer");}else
        if(g_receiver != null && g_local_stream === null){ alert("Please share your microphone to continue");}

        if(g_receiver != null && g_local_stream !=null){ 
        g_check_flag = false;

        $("#preView").hide();
        $("#interface").show();
        }
    });
});    
</script>
<script>
  $(function() {
     $("#selectable").bind( "mousedown", function ( e ) { e.metaKey = true;}).selectable({          // metakey as (CTRL) 
            selected: function(event, ui) { 
            $(ui.selected).addClass("ui-selected").siblings().removeClass("ui-selected");           // hack : for only one selection
            },
            stop: function(){                                                                       // executes when selection complete
                var data = $('.ui-selected').html();
                g_receiver = data;
                if(g_receiver){
                    $('#receiver').html("<b>" + g_receiver + "</b> selected");
                }else{
                    $('#receiver').html('');
                }
                console.log(data);          
            } 
            });
  });
</script>
<style>
  #feedback { font-size: 1.4em; }
  #selectable .ui-selecting { color: orange; }
  #selectable .ui-selected { background: ; color: blue; }
  #selectable { list-style-type: none; margin: 0; padding: 0; width: 60%; }
  #selectable li { margin: 3px; padding: 0.4em; font-size: 1.4em; height: 18px; cursor: pointer }
</style>
<style>
#collapse {
    display: none;
}

.canvas {
    border: solid 1px black;
    cursor: crosshair;
}

.chat-button{
position: fixed; bottom: 0; right: 0; z-index: 9998;    
}
</style>
<body onload="init()">
<div class="container">
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../teacherPanel.php">Home</a></li>
            <li><a href="../View/ListOfCourses.php">Manage Courses</a></li>
            <li><a href="../View/tchQuestionView.php">Questions</a></li>
            <li class="active"><a href="./InteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $username; ?></a></li>
                <li><a href="../Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<div class="jumbotron" style="text-align: center"><h1>INTERACTIVE MODE</h1></div>

<div id="preView">
    <div class='label label-primary'>Connect with </div>
    <ul id="selectable">
    </ul><br>
    <button id="Go">Go</button>
    <p><span id="receiver"></span></p>
</div>
<div id="interface">
<?php include("sidebar.php"); ?>

<center>
<canvas id='can' class="canvas" width="900" height="700"></canvas>
</center>

<?php include("chatbox.php"); ?>	    
</div>

</div>
</body>
</html>
