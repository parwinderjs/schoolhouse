$(document).ready(function(){
var localAudio;
var remoteAudio;
var peerConnection;
var dc;
var peerConnectionConfig = {'iceServers': [{'url': 'stun:stun.services.mozilla.com'}, {'url': 'stun:stun.l.google.com:19302'}]};

var connection = {
    'optional': [
       //{'DtlsSrtpKeyAgreement': true},
       //{'RtpDataChannels': true}
        ]
};

var isCaller;

navigator.getUserMedia = navigator.getUserMedia || navigator.mozGetUserMedia || navigator.webkitGetUserMedia;
window.RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
window.RTCIceCandidate = window.RTCIceCandidate || window.mozRTCIceCandidate || window.webkitRTCIceCandidate;
window.RTCSessionDescription = window.RTCSessionDescription || window.mozRTCSessionDescription || window.webkitRTCSessionDescription;

pageReady();
function pageReady() {
    localAudio = document.getElementById('localAudio');
    remoteAudio = document.getElementById('remoteAudio');
    console.log("Username : " + username);
    serverConnection = new WebSocket('ws://192.168.1.4/ws/');
    serverConnection.onopen = function(){
        console.log("WebSocket : Connected");
        var identity = {
                        "subject": "identity",
                        "name":username,
                        "type": "teacher"
                        };
        serverConnection.send(JSON.stringify(identity));
    }
    serverConnection.onmessage = gotMessageFromServer;

    var constraints = {
        //video: true,
        audio: true, 
    };

    if(navigator.getUserMedia) {
        navigator.getUserMedia(constraints, getUserMediaSuccess, getUserMediaError);
    } else {
        alert('Your browser does not support getUserMedia API');
    }
}

function getUserMediaSuccess(stream) {
    localStream = stream;
    localAudio.src = window.URL.createObjectURL(stream);
}

function start(isCaller) {
    peerConnection = new RTCPeerConnection(peerConnectionConfig, connection);
    peerConnection.onicecandidate = gotIceCandidate;
    peerConnection.onaddstream = gotRemoteStream;
    peerConnection.addStream(localStream);

    datachannel(peerConnection, isCaller);

    if(isCaller) {
        peerConnection.createOffer(gotDescription, createOfferError);
    }
}

function gotMessageFromServer(message) {
    // if it is about sdp or ice
    if(!peerConnection) start(false);

    var signal = JSON.parse(message.data);
    if(signal.sdp) {
        if(signal.sdp.type === "offer"){            // if  it is an offer
        peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp), 
            function(){
            peerConnection.createAnswer(gotDescription, createAnswerError);},
            function(err){console.log(err)});
        }else {                                     // if it is an answer
            peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp),function(){},function(error){console.log(error)});
        }
    } else if(signal.ice) {
        peerConnection.addIceCandidate(new RTCIceCandidate(signal.ice));
    }
}

function gotIceCandidate(event) {
    if(event.candidate != null) {
        var candidate = {
                    "subject": "ice",
                    "to":receiver,
                    "from": username,
                    'ice': event.candidate
        }
        serverConnection.send(JSON.stringify(candidate));
    }
}

function gotDescription(description) {
    console.log('got description');
    peerConnection.setLocalDescription(description, function () {
        var sdp = {
                "subject": "sdp",
                "to":receiver,
                "from": username,
                "sdp" : description
         }
        serverConnection.send(JSON.stringify(sdp));
    }, function() {console.log('set description error')});
}

function gotRemoteStream(event) {
    console.log("got remote stream");
    remoteAudio.src = window.URL.createObjectURL(event.stream);
}

// Error functions....
function getUserMediaError(error) {
    console.log(error);
}
function createOfferError(error) {
    console.log(error);
}
function createAnswerError(error) {
    console.log(error);
}


function datachannel(peerConnection, isCaller){
    dc = peerConnection.createDataChannel("chat", {reliable: true});
    console.log("Channel id: " + dc.id);    
    console.log("Channel state: " + dc.readyState);

    dc.onopen = function () {
        console.log("datachannel open");
        console.log("Channel state: " + dc.readyState);
        if(isCaller){
        //dc.send("Simple Message");
        dc.onerror = function(ev) { console.log("onerror event detected!"); };
        console.log("message sent")
        }
    
    //send message
    $("#send").click(function(){
        var value = $("#input").val();
        $('#chat').append("<p><strong>" + username + " : </strong>" + value + "</p>");
        var message = {
            "subject": "chat";
            "from": username,
            "message": value
        }
        var json = JSON.stringify(message);
        //console.log(json);
        dc.send(json);
        
    });    
    //send canvas img
    var sendImg = function(e){
        var dataURL = canvas.toDataURL();
        dc.send(dataURL);
        findxy('up', e);
    }
    $('#can').mouseup(sendImg);   
        
    peerConnection.ondatachannel = function (event) {               // receiving via datachannel
        //console.log(event.channel);
        receiveChannel = event.channel;
        receiveChannel.onmessage = function(event){
        console.log("received data");
        try{
            var json = JSON.parse(event.data);
            if(json.message){
            $('#chat').append(json.message);
            }
        }catch(e){console.log("message received");}                                                     
        // sync canvas img
        try{
            var img = new Image;
            ctx = $('#can').get(0).getContext('2d');
            img.onload = function(){
              ctx.drawImage(img,0,0);
                };
            img.src = event.data;   
        }catch(e){console.log("Image received");}

        };
    };
};
}

$("#call").click(function(){
    if(receiver === null){ console.log("Receiver not set"); return;}
    start(true);   
});

});//endreadyfunction