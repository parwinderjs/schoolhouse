$(document).ready(function(){
var localAudio;
var remoteAudio;
var peerConnection;
var dc;
var peerConnectionConfig = {'iceServers': [{'url': 'stun:stun.services.mozilla.com'}, {'url': 'stun:stun.l.google.com:19302'}]};

var connection = {
    'optional': [
       //{'DtlsSrtpKeyAgreement': true},
       //{'RtpDataChannels': true}
        ]
};

var isCaller;

navigator.getUserMedia = navigator.getUserMedia || navigator.mozGetUserMedia || navigator.webkitGetUserMedia;
window.RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
window.RTCIceCandidate = window.RTCIceCandidate || window.mozRTCIceCandidate || window.webkitRTCIceCandidate;
window.RTCSessionDescription = window.RTCSessionDescription || window.mozRTCSessionDescription || window.webkitRTCSessionDescription;

pageReady();
function pageReady() {
    localAudio = document.getElementById('localAudio');
    remoteAudio = document.getElementById('remoteAudio');
    //console.log("Username : " + g_username);
    serverConnection = new WebSocket('ws://localhost:8080/');                            //('ws://192.168.1.4/ws/');
    serverConnection.onopen = function(){
        console.log("WebSocket : Connected");
        var identity = {
                        "subject": "identity",
                        "name":g_username,
                        "type": "teacher"
                        };
        serverConnection.send(JSON.stringify(identity));
    }
    serverConnection.onmessage = gotMessageFromServer;

    var constraints = {
        //video: true,
        audio: true, 
    };

    if(navigator.getUserMedia) {
        navigator.getUserMedia(constraints, getUserMediaSuccess, getUserMediaError);
    } else {
        alert('Your browser does not support getUserMedia API');
    }
}

function getUserMediaSuccess(stream) {
    g_local_stream = stream;
    localStream = stream;
    localAudio.src = window.URL.createObjectURL(stream);
}

function start(isCaller) {
    peerConnection = new RTCPeerConnection(peerConnectionConfig, connection);
    peerConnection.onicecandidate = gotIceCandidate;
    peerConnection.onaddstream = gotRemoteStream;
    peerConnection.addStream(localStream);

    datachannel(peerConnection, isCaller);
    console.log(peerConnection.iceConnectionState);
    manageSession();

    if(isCaller) {
        peerConnection.createOffer(gotDescription, createOfferError);
    }
}

//negotiation
function gotMessageFromServer(message) {
    var signal = JSON.parse(message.data);
    
    var sender = signal.from;
    var accepted = false;
    //someone disconnected
    if(signal.subject == "disconnection"){
        var disconnected_peer = signal.peer;
        peerConnection.close();
        alert(disconnected_peer + " has disconnected. Session closed!");
        location.reload();
    }


    // receiving offer
    if(signal.subject == "sdp" && signal.sdp.type === "offer"){
        accepted = window.confirm("Accept Offer from " + sender);
        if(accepted){
            if(g_local_stream == null){
                while(g_local_stream == null){
                alert("Please share your microphone and then click Ok");
                }
            } 
            if(g_local_stream){
                    if(!peerConnection) start(false);
                    g_check_flag = false;
                    $("#preView").hide();
                    $("#interface").show();
                    g_receiver = signal.from;
            }
        }else{
            alert("Offer rejected or an error occured");
            location.reload();
            return;
        }    
    }

if(peerConnection){
    if(signal.subject == "sdp") {
        if(signal.sdp.type === "offer"){            // if  it is an offer
            peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp), function(){peerConnection.createAnswer(gotDescription, createAnswerError);}, function(err){console.log(err)});
        } 
        if(signal.sdp.type === "answer"){                                     // if it is an answer
            peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp),function(){},function(error){console.log(error)});
        }
    } else if(signal.subject == "ice") {
        peerConnection.addIceCandidate(new RTCIceCandidate(signal.ice));
    }  
}    
}//endfn


function gotIceCandidate(event) {
    if(event.candidate != null) {
        var candidate = {
                    "subject": "ice",
                    "to":g_receiver,
                    "from": g_username,
                    'ice': event.candidate
        }
        serverConnection.send(JSON.stringify(candidate));
    }
}

function gotDescription(description) {
    console.log('got description');
    peerConnection.setLocalDescription(description, function () {
        var sdp = {
                "subject": "sdp",
                "to":g_receiver,
                "from": g_username,
                "sdp" : description
         }
        serverConnection.send(JSON.stringify(sdp));
    }, function() {console.log('set description error')});
}

function gotRemoteStream(event) {
    console.log("got remote stream");
    remoteAudio.src = window.URL.createObjectURL(event.stream);
}

// Error functions....
function getUserMediaError(error) {
    console.log(error);
}
function createOfferError(error) {
    console.log(error);
}
function createAnswerError(error) {
    console.log(error);
}


function datachannel(peerConnection, isCaller){
    dc = peerConnection.createDataChannel("chat", {reliable: true});
    console.log("Channel id: " + dc.id);    
    console.log("Channel state: " + dc.readyState);

    dc.onopen = function () {
        console.log("datachannel open");
        console.log("Channel state: " + dc.readyState);
        if(isCaller){
        //dc.send("Simple Message");
        dc.onerror = function(ev) { console.log("onerror event detected!"); };
        //console.log("message sent")
        }
    
    //send message
    $("#send").click(function(){
        var value = $("#input").val();
        $('#chat').append("<p><strong>You : </strong>" + value + "</p>");
        var message = {
            "subject": "chat",
            "from": g_username,
            "text": value
        }
        dc.send(JSON.stringify(message));
        
    });    
    //send canvas img
    var sendImg = function(e){
        var dataURL = canvas.toDataURL();
        var message = {                                     // -----------------------------------------------------
            "subject": "canvas",
            "from": g_username,
            "data": dataURL
        }
        dc.send(JSON.stringify(message));
        //findxy('up', e);
    }
    $('#can').mouseup(sendImg); 


    $("#erase").click(function(){
        console.log("sio");
        dc.send(JSON.stringify({"subject": "canvas_delete", "message": "erase_all"}));
    });  
    
    // receive messages    
    peerConnection.ondatachannel = function (event) {              
        //console.log(event.channel);
        receiveChannel = event.channel;
        receiveChannel.onmessage = function(event){
        console.log("received data");
        message = JSON.parse(event.data);

        if(message.subject === "chat"){
            $('#chat').append("<p><strong>" + message.from + " : </strong>" + message.text + "</p>");
        }
        if(message.subject === "canvas"){
            var img = new Image;
            ctx = $('#can').get(0).getContext('2d');
            img.onload = function(){
              ctx.drawImage(img,0,0);
                };
            img.src = message.data; 
        }
        if(message.subject === "canvas_delete"){
            clearArea();
        }

        if(message.subject === "canvas_delete"){
            //window.alert("Canvas Cleared");
            clearArea();         // a call to canvas function of clearing all of canvas
        }
        };
    };
  }//endfn
}//endfn

function manageSession(){
peerConnection.oniceconnectionstatechange = function() {
    console.log(peerConnection.iceConnectionState);
    if(peerConnection.iceConnectionState == 'connected'){
        var session = {
                "subject": "session",
                "peer1": g_username, 
                "peer2":g_receiver
        }
        serverConnection.send(JSON.stringify(session));
        alert("Connected with " + g_receiver);
    }
    if(peerConnection.iceConnectionState == 'disconnected') {                   // not working
        alert(g_receiver + ' Disconnected');
    }
}
}

$("#call").click(function(){
    if(g_receiver === null){ console.log("Receiver not set"); return;}
    start(true);   
});

});//endreadyfunction