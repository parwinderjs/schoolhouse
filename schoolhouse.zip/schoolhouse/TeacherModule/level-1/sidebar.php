<style type="text/css">
	.pointer{
		cursor: pointer;
	}

</style>

<nav class="navbar navbar-inverse sidebar" role="navigation">
    <div class="container-fluid">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-sidebar-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand">Menu</a>
		</div>
		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-sidebar-navbar-collapse-1">
			<ul class="nav navbar-nav">
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Pen<span class="caret"></span></a>
					<ul class="dropdown-menu" role="menu">
						<li><div id="green" class="pencil-color" style="background-color: green; cursor: pointer">Green</div></li>
                		<li><div id="red" class="pencil-color" style="background-color: red; cursor: pointer">Red</div></li>
                		<li><div id="blue" class="pencil-color" style="background-color: blue; cursor: pointer">Blue</div></li>
                		<li><div id="yellow" class="pencil-color" style="background-color: yellow; cursor: pointer">Yellow</div></li>
                		<li><div id="orange" class="pencil-color" style="background-color: orange; cursor: pointer">Orange</div></li>
					</ul>
				</li>

				<li><a id="white" class="pencil-color" style="cursor: pointer">Eraser</a></li>
				<li><a id="erase" class="" style="cursor: pointer">EraseAll</a></li>
				
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">PenSize<span class="caret"></span></a>
					<ul class="dropdown-menu" role="menu">
						<li><div id="slider" style="background-color: lightblue;"></div></li>	
					</ul>
				</li>					
            
				<li class="dropdown">
					<a href="#" class="dropdown-toggle pointer" data-toggle="dropdown">Local audio stream<span class="caret"></span></a>
					<ul class="dropdown-menu" role="menu">
						<li>
						<div id="phone-controller">
							<audio id="localAudio" controls></audio>
            			</div>
						</li>	
					</ul>
				</li>					

				<li class="dropdown">
					<a class="dropdown-toggle pointer" data-toggle="dropdown">Remote audio stream<span class="caret"></span></a>
					<ul class="dropdown-menu" role="menu">
						<li><audio id="remoteAudio" controls></audio></li>
					</ul>
				</li>
				<li><a id="call" class="pointer">Connect</a></li>
            </ul>
		</div>
	</div>
</nav>


<script>
    $(".pencil-color").click(function(){
        selectColor(this);
    });

    $("#slider").slider({
        value:1,
        min:1,
        max : 24,
        change: function( event, ui ) {
            size = ui.value;
            console.log(ui.value);
        }
    });

    $("#erase").click(function(){
        clearArea();
    });

</script>