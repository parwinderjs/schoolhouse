<?php 
//delete topic with matched with name or id
// also delete the related record to a particular topic
// 1. student rating
// 2. bookmark

include_once("config.php");
if(isset($_POST['topic_id']) && isset($_POST['topic_name'])){
	$conn = connect();
	$topic_id = $_POST['topic_id'];
	$topic_name = $_POST['topic_name'];
	$select = "SELECT * FROM `topics` WHERE `topic_name` = '$topic_name' AND `id` = '$topic_id'";
	$result = mysqli_query($conn, $select);
	$row = mysqli_fetch_assoc($result);
	$content = $row['content'];					// contains video path 
	$delete = "DELETE FROM `topics` WHERE `topic_name` = '$topic_name'";
	mysqli_query($conn, $delete);
	if(mysqli_affected_rows($conn)>0){

			if(file_exists($content)){
				unlink($content);
			}
			if(file_exists("Files/".$topic_name.".jpg")){
				unlink("Files/".$topic_name.".jpg");
			}
	}

	$delete_rating = "DELETE FROM `feedback` WHERE `topic_id` = '$topic_id'";
	mysqli_query($conn, $delete_rating);
	if(mysqli_affected_rows($conn)>0){
		echo json_encode("Deleted");
	}else{
		//echo "Error";
	}	
}//endif

?>