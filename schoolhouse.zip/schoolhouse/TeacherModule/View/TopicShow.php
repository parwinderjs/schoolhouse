<!DOCTYPE html>
<html>
<head>
	<title>CourseContent</title>
	<link rel="stylesheet" href="css/bootswatch.min.css">
</head>
<body>
<?php 
include_once("config.php");
if(isset($_POST['submit'])){
	$chapter_id = $_POST['chapter_id'];
	//validating $chapter_id is pending
	$conn = connect();
	$select = "SELECT * FROM `topics` WHERE `chapter_id` = '$chapter_id'";
	$result = mysqli_query($conn, $select);
}
?>

<div class="container">
<div class="page-header">
<h1>Topics</h1>
</div>
<?php 
	if($result){
		if(mysqli_num_rows($result) == 0){
			echo "No topics added to this chapter";
		}else{
		while($row = mysqli_fetch_assoc($result)){
			echo "<div class='img-thumbnail'>";
			echo "<a href='VideoPlayer.php?video=".$row['id']."'><img src='http://www.wholebodyreboot.com/images/btn-play.png' class='img-thumbnail' alt='play' width='304' height='236'></a>";
			echo "<p>".$row['topic_name']."</p>";
			echo "</div>";	
			}
		}	
	} 
	mysqli_close($conn);
 ?>
</div>
</body>
</html>