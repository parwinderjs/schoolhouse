<?php 
session_start();
if(!isset($_SESSION['username'])){ header("location:../NotLogedIn.html");}
$username = $_SESSION['username'];
$tch_id = $_SESSION['tch_id']
?>
<!DOCTYPE html>
<html>
<head>
	<title>Create MCQ</title>
	<link rel="stylesheet" href="../jquery-ui/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script src="../jquery-ui/jquery-ui.min.js"></script>
</head>
<body>
<div class="container">
<?php  
if(empty($_GET['id'])){
  if(empty($_POST['topic_id'])){
	echo "Topic not mentioned."; exit;
  }
}else{
	if(isset($_GET['id'])){
		$topic_id = intval($_GET['id']);		
	}else{
		if(isset($_POST['topic_id'])){
			$topic_id = intval($_POST['topic_id']);
		}
	}
}
$question_error = $option1_error = $option2_error = $option3_error = $option4_error = '';
?>

<?php 
include_once("config.php");
$conn = connect();

if(isset($_POST['submit'])){
 if(empty($_POST['question'])){
 	$question_error = "(question field should not be empty)";
 }else{
 	$question = $_POST['question'];
 }
 if(empty($_POST['option1'])){
 	$option1_error = "(option field should not be empty)";
 }else{
 	$option1 = $_POST['option1'];
 }
 if(empty($_POST['option2'])){
 	$option2_error = "(option field should not be empty)";
 }else{
 	$option2 = $_POST['option2'];
 }
 if(empty($_POST['option3'])){
 	$option3_error = "(option field should not be empty)";
 }else{
 	$option3 = $_POST['option3'];
 }
 if(empty($_POST['option4'])){
 	$option4_error = "(option field should not be empty)";
 }else{
 	$option4 = $_POST['option4'];
 }

 $correct_option = intval($_POST['correct']);
 
 if(isset($question) && isset($option1) && isset($option2) && isset($option3) && isset($option4) && isset($correct_option)){
 	
 	if(!empty($question)){
 		$s_question = mysqli_escape_string($conn, $question);
 	}
 	if(!empty($option1)){
 		$s_option1 = mysqli_escape_string($conn, $option1);
 	}
 	if(!empty($option2)){
 		$s_option2 = mysqli_escape_string($conn, $option2);
 	}
 	if(!empty($option3)){
 		$s_option3 = mysqli_escape_string($conn, $option3);
 	}
 	if(!empty($option4)){
 		$s_option4 = mysqli_escape_string($conn, $option4);
 	}


 	$insert = "INSERT INTO `mcq` (`topic_id`, `question`, `option1`, `option2`, `option3`, `option4`, `correct_option`) 
 			   VALUES ('$topic_id', '$s_question', '$s_option1', '$s_option2', '$s_option3', '$s_option4', '$correct_option')";

 	mysqli_query($conn, $insert);
 	if(mysqli_affected_rows($conn)>0){
 		echo "Added";
 	}

 }
}
?>


<div class="page-header">
	<h1>Add</h1>
</div>
<form method="post" class="form-group col-md-6">
	<input type="hidden" name="topic_id" value=<?php echo "\"".$topic_id."\""; ?> >
	<label>Question</label><span style="color:red"><?php echo " ".$question_error;?></span>
	<input type="text" name="question" class="form-control">
	<br>
	<label>Option 1</label><span style="color:red"><?php echo " ".$option1_error; ?></span>
	<input type="text" name="option1" class="form-control">
	<label>Option 2</label><span style="color:red"><?php echo " ".$option2_error; ?></span>
	<input type="text" name="option2" class="form-control">
	<label>Option 3</label><span style="color:red"><?php echo " ".$option3_error; ?></span>
	<input type="text" name="option3" class="form-control">
	<label>Option 4</label><span style="color:red"><?php echo " ".$option4_error; ?></span>
	<input type="text" name="option4" class="form-control"><br>
	<label>Correct option</label>
	<select name="correct" class="form-control">
		<option value="1">1</option>
		<option value="2">2</option>
		<option value="3">3</option>
		<option value="4">4</option>
	</select><br>
	<input type="submit" name="submit" value="Add" class="form-control"></input>
</form>
<div class="clearfix"></div>

<div class="page-header">
	<h1>Added</h1>
</div>
<?php  
function getMCQ($conn, $topic_id){
	$select = "SELECT * FROM `mcq` WHERE `topic_id` = '$topic_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		if(mysqli_num_rows($result)>0){
			echo "<label class='label label-info'>Total : ".$count = mysqli_num_rows($result);
			echo "</label><br><br>";
			$question_no = 1;
			while($row = mysqli_fetch_assoc($result)){
				$question = $row['question'];
				$option1 = $row['option1'];
				$option2 = $row['option2'];
				$option3 = $row['option3'];
				$option4 = $row['option4'];
				$correct_option = $row['correct_option'];

				echo "<div class='panel-group panel-primary'><div class='panel-heading'>Question $question_no : ".$question."</div>
				<div class='panel-body'>
				Option1 : ".$option1."<br>Option2 : ".$option2."<br>Option3 : ".$option3."<br>Option4 : ".$option4."</p>";
				echo "</div><div class='panel-footer'><span> Correct Option : ".$correct_option."</span></div></div>";
				$question_no++;
			}
		}
	}
}

getMCQ($conn, $topic_id);
?>

</div>
</body>
</html>