<!DOCTYPE html>
<html>
<head>
	<title>CourseDetail</title>
  <link rel="stylesheet" type="text/css" href="css/cerulean.min.css">	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
<div class="page-header">
<h1>Courses</h1>
</div>
<div class="panel-group" id="accordion">

<?php  
include_once("../Classes/SearchCourse.php");
include_once("config.php");
$conn = connect();

$select = "SELECT * FROM `courses`";
$search = new Search($conn, $select, 6);
$rs = $search->getPageResult();
if(!$rs){echo "No courses";}
if($rs){
  if(mysqli_num_rows($rs) == 0){ echo "No courses"; exit;}
  
while($row = mysqli_fetch_assoc($rs)){
	 echo "<div class='panel panel-default'>";
     echo "<div class='panel-heading'>"; 	
     echo "<h4 class='panel-title'>";
     echo "<a data-toggle='collapse' data-parent='#accordion' href='#collapse".$row['id']."'>".$row['course_name']."</a>";
     echo "</h4>";
     echo "</div>";
     echo "<div id='collapse".$row['id']."' class='panel-collapse collapse in'><div class='panel-body'>";
     echo $row['detail'];
     echo "<br /><br/>";
     selectChapters($row['id'], $conn);
     
     echo "</div></div></div>";
	}


  echo "<ul class='pagination pagination-sm'>";
  echo "<hr>".$search->displayFullNav();
  echo "</ul>";

}//endif


 function selectChapters($course_id, $conn){
    $query = "SELECT * FROM `chapters` WHERE chapters.course_id = '$course_id'";
    $result = mysqli_query($conn, $query)  or mysqli_error($conn);
    if($result){
      if(mysqli_num_rows($result) == 0){
        echo "&nbsp&nbsp<i>Null</i>";
      }else{
        echo "&nbsp<form method='post' action='TopicShow.php' class='form-inline'><label class='control-label'>Select Chapter &nbsp</label><select name='chapter_id'>";
        while($chapter = mysqli_fetch_assoc($result)){
        echo "<option value='".$chapter['id']."'>";
        echo $chapter['chapter_name'];
        echo "</option>";
        }
        echo "</select>&nbsp<button type='submit' name='submit' class='btn btn-default btn-xs'>GO</button></form>";
      }
    }  
 } 

?>
</div>
</div>
</body>
</html>
