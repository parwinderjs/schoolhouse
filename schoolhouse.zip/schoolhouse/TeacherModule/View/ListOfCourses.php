<?php
include_once("../Classes/Teacher.php");
session_start();
if(!isset($_SESSION['username'])){ header("location:NotLogedIn.html");}
$username = $_SESSION['username'];
$tch_id= $_SESSION['tch_id'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		Course List
	</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../teacherPanel.php">Home</a></li>
            <li class="active"><a href="./ListOfCourses.php">Manage Courses</a></li>
            <li><a href="./tchQuestionView.php">Questions</a></li>
            <li><a href="../level-1/InteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $username; ?></a></li>
                <li><a href="../Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<br>
<div class="page-header">
	<h1>List of courses</h1>
</div>
<ol class="breadcrumb">
  <li><a href="#"><?php echo $username ?></a></li>
</ol>
<ol>
<?php
  include_once("config.php");
  $conn = connect(); 
	$result = getCourses($conn, $tch_id);
	while($row = mysqli_fetch_assoc($result)){
		$course_name = $row['course_name'];
    $course_id = $row['id'];
    echo
    "<li>
    <form method='get' action='ListOfChapters.php'>
    <input type='hidden' name='c_id' value='".$course_id."'>
    <input type='submit' class='btn btn-link' value='".$course_name."'>
    </form>
    </li>";
	}

  function getCourses($conn, $teacher_id){
      $select = "SELECT * FROM `courses` WHERE courses.teacher_id = '$teacher_id'";
      $result = mysqli_query($conn, $select);
      return $result;
  }
?>
</ol>
<?php
  $name_error = $detail_error = '';
?>
<ul>
<div class="container col-md-3">
  <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">+</button>
  <div id="demo" class="collapse">
  	<form method="post">
	<label>Course Name : </label><?php echo $name_error; ?>
	<input type="text" name="course_name" class="form-control" required><br />
	<label>Detail : </label><?php echo $detail_error; ?><br />
	<textarea name="detail" class="form-control" required></textarea><br />
	<input type="submit" value="Add" name="submit" class="btn btn-primary">
	</form>
  </div>
 </div> 
 </ul>
<?php 
	if(isset($_POST['submit'])){
		$course_name = $_POST['course_name'];
		$detail = $_POST['detail'];
    if(empty($course_name) || empty($detail)){
      if(empty($course_name)){
        $name_error = "<span style='background-color=red'>Name empty</span>";
      }
      if(empty($detail)){
        $detail_error = "<span style='background-color=red'>Field empty</span>";
      }
    }else{
        $s_course_name = mysqli_escape_string($conn, $course_name);
        $s_detail = mysqli_escape_string($conn, $detail);
        if(addCourse($conn, $s_course_name, $s_detail, $tch_id)){
        header('Location:'.$_SERVER['PHP_SELF']);
        }
    }
	}

  function addCourse($conn, $course_name, $detail, $teacher_id){
      $insert = "INSERT INTO `courses`(`course_name`, `detail`, `teacher_id`) VALUES ('$name', '$detail', '$teacher_id')";
      mysqli_query($conn, $insert);
      if(mysqli_affected_rows($conn) > 0){
        return true;
      }else {
        return false;
      }    
  }
?>	
</div>
</body>
</html>