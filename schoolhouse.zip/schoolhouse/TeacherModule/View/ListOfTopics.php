<?php
include_once("../Classes/Teacher.php");
ob_start();
session_start();
if(!isset($_SESSION['username'])){ header("location:NotLogedIn.html");}
$username = $_SESSION['username'];
$teacher_id = $_SESSION['tch_id'];

$course_id = intval($_GET['c_id']);
if(!filter_var($course_id, FILTER_VALIDATE_INT)){        // Note: also false for $course_id == 0
  echo "Course id is not valid";
  exit;
}
$chapter_id = intval($_GET['ch_id']);
if(!filter_var($chapter_id, FILTER_VALIDATE_INT)){        // Note: also false for $course_id == 0
  echo "Chapter id is not valid";
  exit;
}

include_once("config.php");
$conn = connect();
$course_name = getCourseName($conn, $course_id);
$chapter_name = getChapterName($conn, $chapter_id);

function getCourseName($conn, $course_id){
  $select = "SELECT * FROM `courses` WHERE `id` = '$course_id'";
  $result = mysqli_query($conn, $select);
  $row = mysqli_fetch_assoc($result);
  return $row['course_name'];
}

function getChapterName($conn, $chapter_id){
  $select = "SELECT * FROM `chapters` WHERE `id` = '$chapter_id'";
  $result = mysqli_query($conn, $select);
  $row = mysqli_fetch_assoc($result);
  return $row['chapter_name'];
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		Course List
	</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- context-menu dependencies -->
<link rel="stylesheet" href="./src/jquery.contextMenu.css">
<script src="./src/jquery.contextMenu.js"></script>
<script src="./src/jquery.ui.position.min.js"></script>


<script type="text/javascript">
    $(function() {
        $.contextMenu({
            selector: '.topic_name',                                                      // element class or id to be selected
            callback: function(key, options) {
                var m = "clicked: " + key + " on " + $(this).text();
                var prev = $(this).text();
                id = $(this).attr("id");
                //window.console && console.log(m) || alert(m);
                if(key == "edit"){
                  //var string = "&nbsp<input placeholder='Rename' id='new_name'></input><input type='hidden' id='topic_id' value=" + id + "><button id='rename' class='btn btn-primary btn-xs'>Save</button>";
                	//$(this).append(string);
                }
                if(key == "mcq"){
                  window.open("./createMCQ.php?id=" + id);
                }
                if(key == "delete"){
                	var confirm = window.confirm("Are you sure?");
                	if(confirm){
                		//alert("You selected delete");

                		$.ajax({
                			url: "deleteTopic.php",
                			method: "post",
                			data : {
                				topic_id : id,
                				topic_name : prev
                			},
                			success: function(result, status){
                				//if(result === "Deleted"){
                					alert(result);
                					location.reload();	
                				//}
                				
                			}
                		});
                	}
                }
            },
            items: {
                //"edit": {name: "Edit", icon: "edit"},
                "mcq": {name: "Add mcq", icon: "edit"},
                "delete": {name: "Delete", icon: "delete"},
                "quit": {name: "Quit", icon: function(){
                    return 'context-menu-icon context-menu-icon-quit';
                }}
            }
        });

        $('.topic_name').on('click', function(e){
            //alert('clicked', this + content);
        });

    });
</script>
</head>
<body>
<div class="container">
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../teacherPanel.php">Home</a></li>
            <li class="active"><a href="./ListOfCourses.php">Manage Courses</a></li>
            <li><a href="./tchQuestionView.php">Questions</a></li>
            <li><a href="../level-1/InteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $username; ?></a></li>
                <li><a href="../Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<br>
<div class="page-header">
	<h1>List of Topics</h1>
</div>

<ol class="breadcrumb">
  <li><a href="#"><?php echo $username ?></a></li>
  <li><a href="#"><?php echo $course_name; ?></a></li>
  <li><a href="#"><?php echo $chapter_name; ?></a></li>
</ol>

<ol>
<?php 
 	if($result = getTopics($conn, $course_id, $chapter_id)){
	while($row = mysqli_fetch_assoc($result)){
		$topic_id = $row['id'];
		$topic_name = $row['topic_name'];
		echo "<li id=$topic_id class='topic_name'><a href=./VideoPlayer.php?video=$topic_id>".$topic_name."</a></li>";
	}
	}else {
		echo "No topics added yet<br>";
	}

  function getTopics($conn, $course_id, $chapter_id){
    $select = "SELECT * FROM `topics` WHERE `course_id` = '$course_id' AND `chapter_id` = '$chapter_id'";
    $result = mysqli_query($conn, $select);
    return $result;
  }
?>
</ol>
<ul>
<div class="container col-md-3">
  <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">+</button>
  <div id="demo" class="collapse">
  		<form method="post" enctype="multipart/form-data">
			<legend>Upload</legend>
			<label>Topic name</label>
			<input type="text" name="topic_name"><br /><br/>
			<input type="file" name="video" class="btn btn-primary" /><br />
			
			<input type="submit" name="upload" value="Upload" class="btn btn-default" />
		</form>
  </div>
 </div> 
 </ul>	
 <?php 
 	$upload_error = '';

	if(isset($_POST['upload'])) {
		$topic_name = $_POST['topic_name'];
		$file_name = $_FILES["video"]["name"];
		$file_size = $_FILES["video"]["size"];
		$file_path = "Files/".$file_name;
    $file_type = $_FILES["video"]["type"];

    if(empty($file_name) || empty($topic_name)){
      if(empty($file_name)){
        $upload_error = "Video-file is empty";  
      }else if(empty(($topic_name))){
        $upload_error = "File-name is empty";
      }else{
        $upload_error = "Video-file and File-name is empty";
      }
    }
		if(!empty($file_name) && $file_size/(1024 * 1024) > 20){
			$upload_error .= "<br>File size exceeds 20mb.";
		}
		if(!empty($file_name) && $file_type !== "video/mp4"){
			$upload_error .= "<br>Only mp4 format is allowed";
		}
		if(!file_exists("Files/".$_FILES["video"]["name"]) && empty($upload_error)){

			if(move_uploaded_file($_FILES["video"]["tmp_name"], "Files/".$_FILES["video"]["name"])){
				$is_inserted = addTopic($conn, $topic_name, $file_path, $course_id, $chapter_id, $teacher_id);  
				if($is_inserted){
        				$image_file = "Files/".$topic_name.".jpg";
				      	if(createThumbnail($file_path, $image_file)){
                  		header('Location:'.$_SERVER['PHP_SELF'].'?c_id='.$course_id.'&ch_id='.$chapter_id); 
                  		//echo $file_path." ___ ". $image_file;       
              			}
						}else{
				$upload_error = "Error storing path";
				}
			}else {
				$upload_error = "File not stored";
			}
		}
		else if(empty($upload_error)){
			$upload_error = "File with this name already Existed";
		}

	}

  ob_flush();

  function addTopic($conn, $topic_name, $file_path, $course_id, $chapter_id, $teacher_id){
      $insert = "INSERT INTO `topics` (`topic_name`, `content`, `chapter_id`, `course_id`, `teacher_id`) VALUES ('$topic_name', '$file_path', '$chapter_id','$course_id', '$teacher_id')";
      $result = mysqli_query($conn, $insert);
      if(mysqli_affected_rows($conn)>0){
        $topic_id = mysqli_insert_id($conn);
        return true;
      }else{
        return false;
      }
  }

	function createThumbnail($video_path, $image_file){
			$ffmpeg = "C:\\ffmpeg\\bin\\ffmpeg";
			//$video_path = "Files/videoplayback.mp4";
			//$image_file = "Thumbnail/1.jpg";
			$size = "400x320";
			$ss_at = 50;
			$cmd = "$ffmpeg -i $video_path -an -ss $ss_at -s $size $image_file";
			if(!shell_exec($cmd)){
			   return true;
			}else{
				 return false;
			}
	}
?>
<span style="color:red"><?php echo $upload_error; ?></span>
</div>	
</body>
</html>