<?php 
session_start();
if(!isset($_SESSION['username'])){ header("location:NotLogedIn.html");}
$username = $_SESSION['username'];
$tch_id = $_SESSION['tch_id'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>QuestionView</title>
	<link rel="stylesheet" href="../jquery-ui/jquery-ui.css">
	<link rel="stylesheet" href="css/bootswatch.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="../jquery-ui/jquery-ui.min.js"></script>

</head>
<?php
include_once("config.php");
$conn = connect();
// questions
//id question student_id topic_id status
function getQuestions($conn, $teacher_id){
	if($conn){
		$select = "SELECT * FROM `questions` WHERE `status` = 'pending' AND `topic_id` IN (SELECT `id` FROM `topics` WHERE `teacher_id` = '$teacher_id')";
		$result2 = mysqli_query($conn, $select) or die(mysqli_error($conn));
		if($result2){
			if(mysqli_num_rows($result2)>0){
			echo "<div class='panel-group'>";
			$question_no = 1;
			while($row = mysqli_fetch_assoc($result2)){
				echo "<br/>";
				echo "<div class='panel panel-danger'>"; 
				echo "<div class='panel-heading'>Q".$question_no.": ".$row['question']."</div>";
				echo "<div class='panel-body'>";
				echo "<span class='col-md-3'><span class='label label-info'>Asked by</span> : ".askedBy($conn, $row['student_id'])." </span>";
echo "<span class='col-md-3'><span class='label label-info'>Topic</span> :<a href='VideoPlayer.php?video=".$row['topic_id']."'>".questionTopic($conn, $row['topic_id'])."</a> </span>";
				echo "<br>";
				echo "<br><form method='post' class='form-group'>
						<input type='hidden'  name='topic_id' value='".$row['topic_id']."'>
						<input type='hidden'  name='question_id' value='".$row['id']."'>
						<textarea name='answer'  class='form-control' placeholder='Write Answer' required></textarea><br>
						<select name='visibility'  class='form-control'><option>Private</option><option>Public</option></select><br>
						<button name='submit' class='btn col-md-12' value='submit'>Send</button></form>";

				echo "</div></div>";
				$question_no++;
			}
			echo "</div>";
			}else{
				echo "No question to answer";
			}
		}else{
			echo "Not available";
		}
	}else{
		echo "Connection problem";
	}
}	

function getAnsweredQuestion($conn, $teacher_id){
	if($conn){
		$select = "SELECT * FROM `questions` WHERE `status` = 'answered' AND `topic_id` IN (SELECT `id` FROM `topics` WHERE `teacher_id` = '$teacher_id')";

		$result = mysqli_query($conn, $select) or die(mysqli_error($conn));
		if($result){
			if(mysqli_num_rows($result)>0){
			echo "<div class='panel-group'>";
			$question_no = 1;
			while($row = mysqli_fetch_assoc($result)){
				echo "<br/>";
				echo "<div class='panel panel-success'>"; 
				echo "<div class='panel-heading'>Q".$question_no.": ".$row['question']."</div>";
				echo "<div class='panel-body'>";
				echo "<span class='col-md-3'><span class='label label-info'>Asked by</span> : ".askedBy($conn, $row['student_id'])." </span>";
				echo "<span class='col-md-3'><span class='label label-info'>Topic</span> :<a href='VideoPlayer.php?video=".$row['topic_id']."'>".questionTopic($conn, $row['topic_id'])."</a> </span>";
				echo "<div class='clearfix'></div><br>";
				echo "<blockquote><span class='label label-success'>Ans</span><br><pre>".getAnswer($conn, $row['id'])."</pre></blockquote></div></div>";

				}
			echo "</div>";
			$question_no++;
			}else{
				echo "No question answered";
			}
		}	
	}
}

function getAnswer($conn, $question_id){
	$select = "SELECT * FROM `answers` WHERE `question_id` = '$question_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		$row = mysqli_fetch_assoc($result);
		return $row['answer'];
	}
}

function askedBy($conn, $student_id){
	$select = "SELECT * FROM `students` WHERE `id` = '$student_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		$row = mysqli_fetch_assoc($result);
		return $row['first_name']." ".$row['last_name'];
	}else{
		return "Not available";
	}
}

function questionTopic($conn, $topic_id){
	$select = "SELECT * FROM `topics` WHERE `id` = '$topic_id'";
	$result = mysqli_query($conn, $select);
	if($result){
		$row = mysqli_fetch_assoc($result);
		return $row['topic_name'];
	}else{
		return "Not available";
	}
}

function sendAnswer($conn, $answer, $question_id, $topic_id, $visibility ){
// id answer question_id topic_id visibility
	$answer = nl2br($answer);
	$insert = "INSERT INTO `answers` (`answer`, `question_id`, `topic_id`, `visibility`) VALUES ('$answer', '$question_id','$topic_id', '$visibility')";
	mysqli_query($conn, $insert);
	if(mysqli_affected_rows($conn) > 0){
		changeQuestionStatus($conn, $question_id);
		header("location:".$_SERVER['PHP_SELF']);
		return true;
	}else{
		return false;
	}
}

function changeQuestionStatus($conn, $question_id){
	$update = "UPDATE `questions` SET `status` = 'answered' WHERE `id` = '$question_id'";
	mysqli_query($conn, $update);
}

?>
<body>
<div class="container">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../teacherPanel.php">Home</a></li>
            <li><a href="./ListOfCourses.php">Manage Courses</a></li>
            <li  class="active"><a href="./tchQuestionView.php">Questions</a></li>
            <li><a href="../level-1/InteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $username; ?></a></li>
                <li><a href="../Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<div class="jumbotron" style="text-align: center"><h1>QUESTION PANEL</h1></div>

<?php 
echo "<h2>Pending</h2>";
getQuestions($conn, $tch_id);


if(isset($_POST['submit'])){
	if(!empty($_POST['answer'])){
		$answer = mysqli_escape_string($conn, $_POST['answer']);
		$question_id = $_POST['question_id'];
		$topic_id = $_POST['topic_id'];
		$visibility = $_POST['visibility'];
		if(sendAnswer($conn, $answer, $question_id, $topic_id, $visibility)){echo "Sent";}else { echo "error";};
	}else{
		//echo "Answer is empty";
		//exit;
	}
}


echo "<h2>Answered</h2>";
getAnsweredQuestion($conn, $tch_id);
?>
</div>
</body>
</html>