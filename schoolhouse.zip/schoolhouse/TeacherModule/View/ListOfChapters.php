<?php
include_once("config.php");
session_start();
if(!isset($_SESSION['username'])){ header("location:NotLogedIn.html");}
$username = $_SESSION['username'];
$tch_id = $_SESSION['tch_id'];

$course_id = intval($_GET['c_id']);
if(filter_var($course_id, FILTER_VALIDATE_INT)){        // Note: also false for $course_id == 0
 //
}else{
  echo "Course id is not valid";
  exit; 
}
$conn = connect();
$course_name = getCourseName($conn, $course_id);

function getCourseName($conn, $course_id){
  $select = "SELECT * FROM `courses` WHERE `id` = '$course_id'";
  $result = mysqli_query($conn, $select);
  $row = mysqli_fetch_assoc($result);
  return $row['course_name'];
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>
		Course List
	</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SCHOOLHOUSE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../teacherPanel.php">Home</a></li>
            <li class="active"><a href="./ListOfCourses.php">Manage Courses</a></li>
            <li><a href="./tchQuestionView.php">Questions</a></li>
            <li><a href="../level-1/InteractiveMode.php">Interactive Mode</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
                <li><a><?php echo $username; ?></a></li>
                <li><a href="../Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<br>
<div class="page-header">
	<h1>List of chapters</h1>
</div>

<ol class="breadcrumb">
  <li><a href="#"><?php echo $username ?></a></li>
  <li><a href="#"><?php echo $course_name; ?></a></li>
</ol>
<ol>
<?php 
	$result = getChapters($conn, $course_id);
	while($row = mysqli_fetch_assoc($result)){
		$chapter_name = $row['chapter_name'];
    $chapter_id = $row['id'];
		echo "<li><a href='ListOfTopics.php?c_id=".$course_id."&ch_id=".$chapter_id."'>".$chapter_name."</a></li>";
	}

  function getChapters($conn, $course_id){
      $select = "SELECT * FROM `chapters` WHERE chapters.course_id = '$course_id'";
      $result = mysqli_query($conn, $select);
      return $result;
  }
?>
</ol>

<ul>
<div class="container col-md-3">
  <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">+</button>
  <div id="demo" class="collapse">
  	<form method="post">
	<label>Chapter Name : </label>
	<input type="text" name="chapter_name" class="form-control" required><br />
	<input type="submit" value="Add" name="add" class="btn btn-primary">
	</form>
  </div>
 </div> 
 </ul>	

<?php 
	if(isset($_POST['add'])){
		$chapter_name = $_POST['chapter_name'];
    if(empty($chapter_name)){
        //
    }else{
      $s_chapter_name = mysqli_escape_string($conn, $chapter_name);
      if(addChapter($conn, $chapter_name, $course_id)){
	 	   header('Location:'.$_SERVER['PHP_SELF'].'?c_id='.$course_id);
	   }
    }
  }

  function addChapter($conn, $chapter_name, $course_id){
    $insert = "INSERT INTO `chapters`(`chapter_name`,`course_id`) VALUES ('$chapter_name','$course_id')";
      mysqli_query($conn, $insert);
      if(mysqli_affected_rows($conn)>0){
        return true;
      }else {
        return false;
      }
  }
?>	
</div>
</body>
</html>