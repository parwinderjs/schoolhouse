<!DOCTYPE html>
<html>
<head>
	<title>VideoPlayer</title>
	<link rel="stylesheet" href="css/bootswatch.min.css">
</head>
<body>
<div class="container">
<?php 
if(isset($_GET['video'])){
	$topic_id = intval($_GET['video']);
}else{
	echo "Error loading video";
	exit;
}
?>
 <video width="700" height="500" controls>
  <source src="mp4.php?video=<?php echo $topic_id ?>" type="video/mp4">
</video>
</div>
</body>
</html>