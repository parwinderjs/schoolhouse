<?php 

require './vendor/autoload.php';

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use ChatApp\Chat;


/*
IoServer allows us to receive, read and write, and close connections, as well as handle errors.
HttpServer allows us to parse incomming HTTP requests.
WsServer is the WebSocket server. Allows to talk to browsers which implement the WebSocket API.
*/
$server = IoServer::factory(new HttpServer(new WsServer(new Chat())),8080);

$server->run();
echo "WebSocket running..."
?>