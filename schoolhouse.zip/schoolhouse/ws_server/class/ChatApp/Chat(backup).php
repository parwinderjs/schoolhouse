<?php 
namespace ChatApp;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

include_once("Database.php");

// MessageComponentInterface contains blueprint for the methods like onOpen, onClose, and onMessage

class Chat implements MessageComponentInterface {
 protected $clients;
 public $update_flag;

 public function __construct() {
 	$this->clients = new \SplObjectStorage;
 }

 // ConnectionInterface represents the connection to the application
 public function onOpen(ConnectionInterface $conn){
 	//store the new connection
 	$this->clients->attach($conn);
 	echo "Someone connected\n";
 }

 /* onMessage : This method is called every time a message is sent by a specific client in the browser. The connection object of the client who sent the message, as well as the actual message
 are passed along as an argument every time this method is called. Loop through all currently connected clients and send the message to them except the one who sent.*/

 public function onMessage(ConnectionInterface $from, $msg){
 	$this->storeIdentity($msg);								// if someone connected
 	foreach($this->clients as $client){
 		if($from !== $client){     	// if not sender
 			$client->send($msg);	// send message to this client
 		}
 	}//end loop
 }//end

 public function onClose(ConnectionInterface $conn){
 	$this->clients->detach($conn);
 	echo "Someone has disconnected\n";
 }


public function onError(ConnectionInterface $conn, \Exception $e){
	echo "An error has occured: {
		$e->getMessage()}\n"; $conn->close();
	}

function storeIdentity($msg){
	$identity = json_decode($msg);
	if($identity->name){
		$name = $identity->name;
		$db = new Database();
		$conn = $db->getConnection();
		//$conn = mysqli_connect("localhost", "root", "Akalsahae", "schoolhouse") or die(mysqli_connect_error());
		$insert = "INSERT INTO `connected`(`name`) VALUES ('$name')";
		mysqli_query($conn,$insert);
		if(mysqli_affected_rows($conn)){
			echo "Identity Stored : ".$name;
			// here send the owner of room for updation
		}else{
			echo "Error storing its identity : ".mysqli_error();
		}
		mysqli_close($conn);
	};
}
}
?>
