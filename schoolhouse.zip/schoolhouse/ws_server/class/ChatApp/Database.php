<?php 
	namespace ChatApp;
	 
	class Database {
		private $database_name = "schoolhouse";
		private $password = "";
		private $hostname = "localhost";
		private $username = "root";

		function getConnection(){
			$conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->database_name) or die(mysqli_connect_error());
			return $conn;
		}
	}
?>