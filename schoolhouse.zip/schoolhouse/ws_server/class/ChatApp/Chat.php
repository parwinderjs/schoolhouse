<?php
namespace ChatApp;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

include_once("Database.php");

class Chat implements MessageComponentInterface {
    protected $clients;
    protected $connection;

    public function __construct() {
        $this->clients = array();
        $db = new Database();
        $this->connection = $db->getConnection();
    }

    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection to send messages to later
        $this->clients[$conn->resourceId] = $conn;
        echo "New connection! ({$conn->resourceId})\n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $connected_users = count($this->clients) - 1;
        //echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
          //  , $from->resourceId, $msg, $connected_users, $connected_users == 1 ? '' : 's');

        $message = json_decode($msg);
        if($message->subject == "identity"){$this->storeIdentity($from, $msg);}
        if($message->subject == "sdp"){$this->handleSDPorICE($message);}
        if($message->subject == "ice"){$this->handleSDPorICE($message);}
        if($message->subject == "session"){$this->storeSession($message);}
        //if it is newconnection notification
        /*      foreach ($this->clients as $key => $client) {
                if ($from !== $client) {
                    // The sender is not the receiver, send to each client connected
                $client->send($msg);
                }
            }
        */
        // Send a message to a the owner of class (now it is sending to the sender itself)
            //$client = $this->clients[$from->resourceId];
            //$client->send($msg);
    }

    public function onClose(ConnectionInterface $conn) {
        // The connection is closed, remove it, as we can no longer send it messages
        $this->isUserInSession($conn->resourceId);            // if this user was in session send message to another peer of session
        $this->deleteIdentity($conn->resourceId);
             

        unset($this->clients[$conn->resourceId]);

        echo "Connection {$conn->resourceId} has disconnected\n";
        //delete the entry with this resourceId from database
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }


    function storeIdentity($from, $msg){
        $identity = json_decode($msg);
        if($identity->name){
        $name = $identity->name;
        $type = $identity->type;
        $connection = $this->connection;
        //$conn = mysqli_connect("localhost", "root", "Akalsahae", "schoolhouse") or die(mysqli_connect_error());
        $insert = "INSERT INTO `connected`(`resource_id`,`name`,`type`) VALUES ('$from->resourceId','$name','$type')";
        mysqli_query($connection,$insert);
        if(mysqli_affected_rows($connection)){
            echo "Identity Stored : ".$name."\n";
            // here send the owner of room for updation
            return true;
        }else{
            echo "Error storing its identity : ".mysqli_error($connection);
            return false;
        }
    };
    }

    function deleteIdentity($resourceId){
        $connection = $this->connection;
        $delete = "DELETE FROM `connected` WHERE `resource_id` = $resourceId";
        mysqli_query($connection, $delete);
        if(mysqli_affected_rows($connection)){echo "Identity deleted\n";}else {echo "Identity not deleted\n";}
    
    }

    function handleSDPorICE($message){
        $connection = $this->connection;
        $receiver = $message->to;
        $select = "SELECT `resource_id` FROM `connected` WHERE `name` = '$receiver'";
        $result = mysqli_query($connection, $select);
        if($result){
        while($row = mysqli_fetch_array($result)){
            $client = $this->clients[$row[0]];
            $client->send(json_encode($message));
            echo "sdp/ice sent to ".$row['resource_id']." ".$receiver."\n";
        }
        }else{
            return false;
        }
    }//endfn

    function storeSession($message){
        $connection = $this->connection;
        $peer1 = $message->peer1;                   // holds username of first peer
        $peer2 = $message->peer2;                   // holds username of second peer
        
        $select = "SELECT * FROM `session` WHERE (`peer2` = '$peer1') OR (`peer1` = '$peer1' AND `peer2` = '$peer2')"; 
        $result = mysqli_query($connection, $select);
        if($result){
            if(mysqli_num_rows($result)>0){
                echo "\nsession message ignored";                 // when session message sent from another peer, ignore it
                return;
            }else{
                $insert = "INSERT INTO `session` (`peer1`,`peer2`) VALUES ('$peer1', '$peer2')";
                mysqli_query($connection, $insert);
                if(mysqli_affected_rows($connection)>0){
                echo "new session stored\n";
                }                
            }
        }            
    }//endfn


    function isUserInSession($resource_id){
        $select = "SELECT `name` FROM `connected` WHERE `resource_id` = '$resource_id'";
        $result = mysqli_query($this->connection, $select);
        if($result){
            if(mysqli_num_rows($result)>0){
                $row1 = mysqli_fetch_assoc($result);
                $username = $row1['name'];
            $select2 = "SELECT * FROM `session` WHERE `peer1` = '$username' OR `peer2` = '$username'";
            $result2 = mysqli_query($this->connection, $select2);
            if($result2){
                if(mysqli_num_rows($result2)>0){
                    $row = mysqli_fetch_assoc($result2);
                    if($row['peer1'] === $username){                                            // if its peer1, send to peer2
                        $msg = array("subject"=>"disconnection","from"=>"server","to"=>$row['peer2'],"peer"=>$username);
                        $receiver_resource_id = $this->getResourceId($row['peer2']);
                        $client = $this->clients[$receiver_resource_id];
                        $client->send(json_encode($msg));
                        echo $row['peer2']."is informed\n";
                        $this->deleteSession($username);                                        // delete session of disconnected user
                    }else if($row['peer2'] === $username){                                       // if its peer2, send to peer1
                    	$msg = array("subject"=>"disconnection","from"=>"server","to"=>$row['peer1'],"peer"=>$username);
                        $receiver_resource_id = $this->getResourceId($row['peer1']);
                        $client = $this->clients[$receiver_resource_id];
                        $client->send(json_encode($msg));
                         echo $row['peer1']."is informed\n";
                        $this->deleteSession($username);                                        // delete session of disconnected user
                    }    
                }
            }
            }
        }
    }//endfn


    function getResourceId($name){
        $select = "SELECT * FROM `connected` WHERE `name` = '$name'";
        $result = mysqli_query($this->connection, $select);
        if($result){
            if(mysqli_num_rows($result)>0){
                $row = mysqli_fetch_assoc($result);
                return $row['resource_id'];
            }
        }
    }

    function deleteSession($peer){
        $delete = "DELETE FROM `session` WHERE `peer1` = '$peer' OR `peer2` = '$peer'";
        mysqli_query($this->connection, $delete);
        if(mysqli_affected_rows($this->connection)>0){
            echo "Session Deleted\n";
        }
    }
}//endcls

?>